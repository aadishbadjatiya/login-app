import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext.jsx';
import useAuth from './hooks/useAuth.jsx';
import Sidebar from './components/Sidebar.jsx';
import LoginPage from './pages/LoginPage.jsx';
import DashboardPage from './pages/DashboardPage.jsx';
import EmployeesPage from './pages/EmployeesPage.jsx';
import LeavesPage from './pages/LeavesPage.jsx';
import DepartmentsPage from './pages/DepartmentsPage.jsx';
import ReportsPage from './pages/ReportsPage.jsx';
import ProfilePage from './pages/ProfilePage.jsx';

const ProtectedRoute = ({ children }) => {
  const auth = useAuth();
  if (!auth.user || !auth.token) {
    return <Navigate to="/" replace />;
  }
  return children;
};

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <div className="app-shell">
          <Sidebar />
          <main className="app-main">
            <Routes>
              <Route path="/" element={<LoginPage />} />
              <Route
                path="/dashboard"
                element={<ProtectedRoute><DashboardPage /></ProtectedRoute>}
              />
              <Route
                path="/employees"
                element={<ProtectedRoute><EmployeesPage /></ProtectedRoute>}
              />
              <Route
                path="/leaves"
                element={<ProtectedRoute><LeavesPage /></ProtectedRoute>}
              />
              <Route
                path="/departments"
                element={<ProtectedRoute><DepartmentsPage /></ProtectedRoute>}
              />
              <Route
                path="/reports"
                element={<ProtectedRoute><ReportsPage /></ProtectedRoute>}
              />
              <Route
                path="/profile"
                element={<ProtectedRoute><ProfilePage /></ProtectedRoute>}
              />
              <Route path="*" element={<Navigate to="/" />} />
            </Routes>
          </main>
        </div>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
