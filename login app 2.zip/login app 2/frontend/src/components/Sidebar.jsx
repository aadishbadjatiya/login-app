import { NavLink, useNavigate } from 'react-router-dom';
import useAuth from '../hooks/useAuth.jsx';

const navItems = [
  { path: '/dashboard', label: 'Dashboard' },
  { path: '/employees', label: 'Employees' },
  { path: '/leaves', label: 'Leave Requests' },
  { path: '/departments', label: 'Departments' },
  { path: '/reports', label: 'Reports' },
  { path: '/profile', label: 'My Profile' },
];

const Sidebar = () => {
  const { state, logout } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = () => {
    logout();
    navigate('/');
  };

  return (
    <aside className="sidebar">
      <div className="sidebar-header">
        <div>
          <div className="brand-logo">WorkForce</div>
          <div className="brand-tag">Smart HR Toolkit</div>
        </div>
      </div>
      {state.user && (
        <div className="sidebar-profile">
          <div className="avatar-circle">{state.user.name.split(' ').map(w => w[0]).join('').slice(0, 2)}</div>
          <div>
            <div className="profile-name">{state.user.name}</div>
            <div className="profile-role">{state.user.role}</div>
          </div>
        </div>
      )}
      <nav className="sidebar-nav">
        {navItems.map(item => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) => isActive ? 'sidebar-link active' : 'sidebar-link'}
          >
            {item.label}
          </NavLink>
        ))}
      </nav>
      <button className="btn btn-ghost sidebar-logout" onClick={handleSignOut}>
        Sign Out
      </button>
    </aside>
  );
};

export default Sidebar;
