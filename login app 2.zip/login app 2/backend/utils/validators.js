const Joi = require('joi');

const signupSchema = Joi.object({
  name: Joi.string().min(2).max(100).required(),
  email: Joi.string().email().required(),
  password: Joi.string().min(6).required(),
  role: Joi.string().valid('Admin', 'HR', 'Manager', 'Employee').required(),
});

const loginSchema = Joi.object({
  email: Joi.string().email().required(),
  password: Joi.string().required(),
});

const employeeSchema = Joi.object({
  name: Joi.string().min(2).required(),
  email: Joi.string().email().required(),
  department_id: Joi.number().integer().required(),
  designation: Joi.string().required(),
  salary: Joi.number().precision(2).required(),
  phone: Joi.string().required(),
  address: Joi.string().allow('').optional(),
  skill_ids: Joi.array().items(Joi.number().integer()).required(),
  role: Joi.string().valid('Employee').default('Employee'),
});

const passwordResetSchema = Joi.object({
  email: Joi.string().email().required(),
});

const resetPasswordSchema = Joi.object({
  token: Joi.string().required(),
  password: Joi.string().min(6).required(),
});

const leaveRequestSchema = Joi.object({
  employee_id: Joi.number().integer().required(),
  leave_type_id: Joi.number().integer().required(),
  from_date: Joi.date().required(),
  to_date: Joi.date().required(),
  reason: Joi.string().max(500).required(),
});

module.exports = {
  signupSchema,
  loginSchema,
  employeeSchema,
  passwordResetSchema,
  resetPasswordSchema,
  leaveRequestSchema,
};
