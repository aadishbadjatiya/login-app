CREATE TYPE IF NOT EXISTS user_role AS ENUM ('Admin', 'HR', 'Manager', 'Employee');

CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  role user_role NOT NULL,
  verified BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS refresh_tokens (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  token TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS password_resets (
  id SERIAL PRIMARY KEY,
  user_id INTEGER UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  token TEXT NOT NULL,
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL
);

CREATE TABLE IF NOT EXISTS departments (
  id SERIAL PRIMARY KEY,
  department_name TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS skills (
  id SERIAL PRIMARY KEY,
  skill_name TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS employee_profiles (
  id SERIAL PRIMARY KEY,
  user_id INTEGER UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  department_id INTEGER REFERENCES departments(id),
  phone TEXT,
  address TEXT,
  designation TEXT,
  salary NUMERIC(12,2),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS employee_images (
  id SERIAL PRIMARY KEY,
  employee_id INTEGER REFERENCES employee_profiles(id) ON DELETE CASCADE,
  image_url TEXT NOT NULL,
  label TEXT
);

CREATE TABLE IF NOT EXISTS employee_skills (
  id SERIAL PRIMARY KEY,
  employee_id INTEGER REFERENCES employee_profiles(id) ON DELETE CASCADE,
  skill_id INTEGER REFERENCES skills(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS leave_types (
  id SERIAL PRIMARY KEY,
  leave_name TEXT NOT NULL UNIQUE,
  total_days INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS leave_balance (
  id SERIAL PRIMARY KEY,
  employee_id INTEGER REFERENCES employee_profiles(id) ON DELETE CASCADE,
  leave_type_id INTEGER REFERENCES leave_types(id) ON DELETE CASCADE,
  available_days INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS leave_applications (
  id SERIAL PRIMARY KEY,
  employee_id INTEGER REFERENCES employee_profiles(id) ON DELETE CASCADE,
  leave_type_id INTEGER REFERENCES leave_types(id),
  from_date DATE NOT NULL,
  to_date DATE NOT NULL,
  total_days INTEGER NOT NULL,
  reason TEXT,
  status TEXT NOT NULL DEFAULT 'Pending',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS approval_history (
  id SERIAL PRIMARY KEY,
  leave_id INTEGER REFERENCES leave_applications(id) ON DELETE CASCADE,
  approved_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  remarks TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE VIEW IF NOT EXISTS v_employees AS
SELECT u.id AS user_id,
       u.name,
       u.email,
       u.role,
       p.id AS profile_id,
       p.department_id,
       d.department_name,
       p.phone,
       p.address,
       p.designation,
       p.salary,
       p.created_at
FROM users u
JOIN employee_profiles p ON p.user_id = u.id
LEFT JOIN departments d ON d.id = p.department_id;

CREATE VIEW IF NOT EXISTS v_leave_summary AS
SELECT la.id AS leave_id,
       u.name AS employee_name,
       d.department_name,
       lt.leave_name,
       la.from_date,
       la.to_date,
       la.total_days,
       la.reason,
       la.status,
       la.created_at
FROM leave_applications la
JOIN employee_profiles p ON p.id = la.employee_id
JOIN users u ON u.id = p.user_id
LEFT JOIN departments d ON d.id = p.department_id
LEFT JOIN leave_types lt ON lt.id = la.leave_type_id;

CREATE OR REPLACE FUNCTION approve_leave(leave_id INTEGER, approver_id INTEGER, action TEXT, remarks TEXT)
RETURNS VOID AS $$
DECLARE
  application RECORD;
  balance RECORD;
BEGIN
  SELECT * INTO application FROM leave_applications WHERE id = leave_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Leave application not found';
  END IF;

  IF application.status <> 'Pending' THEN
    RAISE EXCEPTION 'Leave application already processed';
  END IF;

  IF action = 'Approved' THEN
    SELECT * INTO balance FROM leave_balance
      WHERE employee_id = application.employee_id AND leave_type_id = application.leave_type_id FOR UPDATE;
    IF NOT FOUND THEN
      RAISE EXCEPTION 'Leave balance not found';
    END IF;
    IF balance.available_days < application.total_days THEN
      RAISE EXCEPTION 'Insufficient leave balance';
    END IF;
    UPDATE leave_balance
      SET available_days = available_days - application.total_days
      WHERE id = balance.id;
    UPDATE leave_applications SET status = 'Approved' WHERE id = leave_id;
  ELSE
    UPDATE leave_applications SET status = 'Rejected' WHERE id = leave_id;
  END IF;

  INSERT INTO approval_history (leave_id, approved_by, action, remarks, created_at)
  VALUES (leave_id, approver_id, action, remarks, NOW());
END;
$$ LANGUAGE plpgsql;

INSERT INTO departments (department_name)
VALUES ('IT'), ('HR'), ('Finance'), ('Marketing'), ('Operations')
ON CONFLICT (department_name) DO NOTHING;

INSERT INTO skills (skill_name)
VALUES ('React'), ('Node.js'), ('PostgreSQL'), ('Python'), ('Java'), ('AWS'), ('Docker'), ('Figma')
ON CONFLICT (skill_name) DO NOTHING;

INSERT INTO leave_types (leave_name, total_days)
VALUES ('Casual', 12), ('Sick', 10), ('Earned', 15), ('Maternity', 90)
ON CONFLICT (leave_name) DO NOTHING;
