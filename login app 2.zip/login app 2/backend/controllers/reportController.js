const db = require('../db');

const summary = async (req, res, next) => {
  try {
    const totalEmployees = await db.query('SELECT COUNT(*) FROM employee_profiles');
    const totalDepartments = await db.query('SELECT COUNT(*) FROM departments');
    const totalLeaves = await db.query('SELECT COUNT(*) FROM leave_applications');
    const pendingLeaves = await db.query("SELECT COUNT(*) FROM leave_applications WHERE status = 'Pending'");
    res.json({
      totalEmployees: Number(totalEmployees.rows[0].count),
      totalDepartments: Number(totalDepartments.rows[0].count),
      totalLeaves: Number(totalLeaves.rows[0].count),
      pendingLeaves: Number(pendingLeaves.rows[0].count),
    });
  } catch (err) {
    next(err);
  }
};

const departmentLeave = async (req, res, next) => {
  try {
    const result = await db.query(
      `SELECT d.department_name,
        SUM(CASE WHEN la.status = 'Approved' THEN 1 ELSE 0 END) AS approved,
        SUM(CASE WHEN la.status = 'Pending' THEN 1 ELSE 0 END) AS pending,
        SUM(CASE WHEN la.status = 'Rejected' THEN 1 ELSE 0 END) AS rejected
      FROM leave_applications la
      JOIN employee_profiles p ON p.id = la.employee_id
      JOIN departments d ON d.id = p.department_id
      GROUP BY d.department_name
      ORDER BY d.department_name`
    );
    res.json(result.rows);
  } catch (err) {
    next(err);
  }
};

const monthlyTrend = async (req, res, next) => {
  try {
    const result = await db.query(
      `SELECT TO_CHAR(created_at, 'YYYY-MM') AS month,
        SUM(total_days) AS total_days
      FROM leave_applications
      GROUP BY month
      ORDER BY month`
    );
    res.json(result.rows);
  } catch (err) {
    next(err);
  }
};

const mostAbsent = async (req, res, next) => {
  try {
    const result = await db.query(
      `SELECT u.name, d.department_name, SUM(la.total_days) AS absent_days
      FROM leave_applications la
      JOIN employee_profiles p ON p.id = la.employee_id
      JOIN users u ON u.id = p.user_id
      LEFT JOIN departments d ON d.id = p.department_id
      WHERE la.status = 'Approved'
      GROUP BY u.name, d.department_name
      ORDER BY absent_days DESC
      LIMIT 1`
    );
    res.json(result.rows[0] || { name: null, department_name: null, absent_days: 0 });
  } catch (err) {
    next(err);
  }
};

module.exports = { summary, departmentLeave, monthlyTrend, mostAbsent };
