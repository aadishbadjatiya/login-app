const multer = require('multer');
const bcrypt = require('bcrypt');
const db = require('../db');
const { employeeSchema } = require('../utils/validators');

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads'),
  filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`),
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024, files: 5 },
  fileFilter: (req, file, cb) => {
    if (!file.mimetype.startsWith('image/')) {
      return cb(new Error('Only image uploads are allowed'));
    }
    cb(null, true);
  },
});

const list = async (req, res, next) => {
  try {
    const result = await db.query(
      `SELECT
        u.id AS employee_id,
        u.name,
        u.email,
        u.role,
        u.verified,
        u.created_at,
        p.id AS profile_id,
        p.designation,
        p.salary,
        p.phone,
        p.address,
        d.department_name,
        COALESCE(json_agg(DISTINCT jsonb_build_object('skill_id', s.id, 'skill_name', s.skill_name)) FILTER (WHERE s.id IS NOT NULL), '[]') AS skills,
        COALESCE(json_agg(DISTINCT jsonb_build_object('image_url', i.image_url, 'label', i.label)) FILTER (WHERE i.id IS NOT NULL), '[]') AS images
      FROM employee_profiles p
      JOIN users u ON p.user_id = u.id
      LEFT JOIN departments d ON p.department_id = d.id
      LEFT JOIN employee_skills es ON es.employee_id = p.id
      LEFT JOIN skills s ON s.id = es.skill_id
      LEFT JOIN employee_images i ON i.employee_id = p.id
      GROUP BY u.id, p.id, d.department_name
      ORDER BY u.name`
    );
    res.json(result.rows);
  } catch (err) {
    next(err);
  }
};

const getById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const result = await db.query(
      `SELECT
        u.id AS employee_id,
        u.name,
        u.email,
        u.role,
        p.id AS profile_id,
        p.designation,
        p.salary,
        p.phone,
        p.address,
        d.department_name,
        COALESCE(json_agg(DISTINCT jsonb_build_object('skill_id', s.id, 'skill_name', s.skill_name)) FILTER (WHERE s.id IS NOT NULL), '[]') AS skills,
        COALESCE(json_agg(DISTINCT jsonb_build_object('image_url', i.image_url, 'label', i.label)) FILTER (WHERE i.id IS NOT NULL), '[]') AS images
      FROM employee_profiles p
      JOIN users u ON p.user_id = u.id
      LEFT JOIN departments d ON p.department_id = d.id
      LEFT JOIN employee_skills es ON es.employee_id = p.id
      LEFT JOIN skills s ON s.id = es.skill_id
      LEFT JOIN employee_images i ON i.employee_id = p.id
      WHERE p.id = $1
      GROUP BY u.id, p.id, d.department_name`,
      [id]
    );
    if (!result.rows.length) return res.status(404).json({ error: 'Employee not found' });
    res.json(result.rows[0]);
  } catch (err) {
    next(err);
  }
};

const create = async (req, res, next) => {
  const client = await db.getClient();
  try {
    const { error, value } = employeeSchema.validate(req.body);
    if (error) return res.status(400).json({ error: error.details[0].message });

    await client.query('BEGIN');
    const existing = await client.query('SELECT id FROM users WHERE email = $1', [value.email]);
    if (existing.rows.length) {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: 'User email already in use' });
    }

    const password = await bcrypt.hash('Employee123!', 12);
    const userResult = await client.query(
      'INSERT INTO users (name, email, password, role, verified, created_at) VALUES ($1, $2, $3, $4, true, NOW()) RETURNING id',
      [value.name, value.email, password, 'Employee']
    );
    const userId = userResult.rows[0].id;

    const profileResult = await client.query(
      'INSERT INTO employee_profiles (user_id, department_id, phone, address, designation, salary, created_at) VALUES ($1, $2, $3, $4, $5, $6, NOW()) RETURNING id',
      [userId, value.department_id, value.phone, value.address, value.designation, value.salary]
    );
    const employeeId = profileResult.rows[0].id;

    for (const skillId of value.skill_ids) {
      await client.query('INSERT INTO employee_skills (employee_id, skill_id) VALUES ($1, $2)', [employeeId, skillId]);
    }

    const leaveTypes = await client.query('SELECT id, total_days FROM leave_types');
    for (const row of leaveTypes.rows) {
      await client.query('INSERT INTO leave_balance (employee_id, leave_type_id, available_days) VALUES ($1, $2, $3)', [employeeId, row.id, row.total_days]);
    }

    await client.query('COMMIT');
    res.status(201).json({ message: 'Employee created successfully', employee_id: employeeId });
  } catch (err) {
    await client.query('ROLLBACK');
    next(err);
  } finally {
    client.release();
  }
};

const update = async (req, res, next) => {
  const client = await db.getClient();
  try {
    const { id } = req.params;
    const { error, value } = employeeSchema.validate(req.body);
    if (error) return res.status(400).json({ error: error.details[0].message });

    await client.query('BEGIN');
    const profileResult = await client.query('SELECT user_id FROM employee_profiles WHERE id = $1', [id]);
    if (!profileResult.rows.length) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Employee not found' });
    }
    const userId = profileResult.rows[0].user_id;

    await client.query('UPDATE users SET name = $1, email = $2 WHERE id = $3', [value.name, value.email, userId]);
    await client.query(
      'UPDATE employee_profiles SET department_id = $1, phone = $2, address = $3, designation = $4, salary = $5 WHERE id = $6',
      [value.department_id, value.phone, value.address, value.designation, value.salary, id]
    );

    await client.query('DELETE FROM employee_skills WHERE employee_id = $1', [id]);
    for (const skillId of value.skill_ids) {
      await client.query('INSERT INTO employee_skills (employee_id, skill_id) VALUES ($1, $2)', [id, skillId]);
    }

    await client.query('COMMIT');
    res.json({ message: 'Employee updated successfully' });
  } catch (err) {
    await client.query('ROLLBACK');
    next(err);
  } finally {
    client.release();
  }
};

const remove = async (req, res, next) => {
  const { id } = req.params;
  const client = await db.getClient();
  try {
    await client.query('BEGIN');
    const profileResult = await client.query('SELECT user_id FROM employee_profiles WHERE id = $1', [id]);
    if (!profileResult.rows.length) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Employee not found' });
    }
    const userId = profileResult.rows[0].user_id;
    await client.query('DELETE FROM employee_profiles WHERE id = $1', [id]);
    await client.query('DELETE FROM users WHERE id = $1', [userId]);
    await client.query('COMMIT');
    res.json({ message: 'Employee deleted' });
  } catch (err) {
    await client.query('ROLLBACK');
    next(err);
  } finally {
    client.release();
  }
};

const uploadImages = async (req, res, next) => {
  const handler = upload.array('files', 5);
  handler(req, res, async err => {
    if (err) return next(err);
    const employeeId = Number(req.body.employee_id);
    if (!employeeId) return res.status(400).json({ error: 'employee_id is required' });

    try {
      const imageRows = [];
      for (const file of req.files) {
        const url = `/uploads/${file.filename}`;
        const label = req.body.label || file.originalname;
        await db.query('INSERT INTO employee_images (employee_id, image_url, label) VALUES ($1, $2, $3)', [employeeId, url, label]);
        imageRows.push({ image_url: url, label });
      }
      res.json({ message: 'Uploaded successfully', images: imageRows });
    } catch (error) {
      next(error);
    }
  });
};

module.exports = { list, getById, create, update, remove, uploadImages };
