const express = require("express");
const router = express.Router();
const db = require("../config/db");


// SIGNUP
router.post("/signup", async (req, res) => {
  try {
    const { name, email, password } = req.body;

    await db.query(
      "INSERT INTO users(name,email,password) VALUES($1,$2,$3)",
      [name, email, password]
    );

    res.json({
      success: true,
      message: "Signup Successful",
    });
  } catch (err) {
    console.log(err);
    res.status(500).json({
      success: false,
      message: "Signup Failed",
    });
  }
});


// LOGIN
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await db.query(
      "SELECT * FROM users WHERE email=$1 AND password=$2",
      [email, password]
    );

    if (user.rows.length === 0) {
      return res.status(401).json({
        success: false,
        message: "Invalid Credentials",
      });
    }

    // SESSION CREATE
    req.session.user = {
      id: user.rows[0].id,
      name: user.rows[0].name,
      email: user.rows[0].email,
    };

    res.json({
      success: true,
      message: "Login Successful",
      user: req.session.user,
    });
  } catch (err) {
    console.log(err);
  }
});


// CHECK SESSION
router.get("/check-session", (req, res) => {
  if (req.session.user) {
    return res.json({
      loggedIn: true,
      user: req.session.user,
    });
  }

  res.json({
    loggedIn: false,
  });
});


// LOGOUT
router.post("/logout", (req, res) => {
  req.session.destroy(() => {
    res.json({
      success: true,
      message: "Logged Out",
    });
  });
});

module.exports = router;