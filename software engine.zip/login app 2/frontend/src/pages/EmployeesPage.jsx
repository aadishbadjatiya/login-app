import { useEffect, useMemo, useState } from 'react';
import api from '../services/api.js';
import useAuth from '../hooks/useAuth.jsx';
import Btn from '../components/Btn.jsx';
import Card from '../components/Card.jsx';
import Badge from '../components/Badge.jsx';
import { demoEmployees, demoDepartments, demoSkills } from '../data/demo.js';

const EmployeesPage = () => {
  const { state } = useAuth();
  const [employees, setEmployees] = useState(demoEmployees);
  const [departments, setDepartments] = useState(demoDepartments);
  const [skills, setSkills] = useState(demoSkills);
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', department_id: '', designation: '', salary: '', phone: '', address: '', skill_ids: [] });
  const [error, setError] = useState('');

  useEffect(() => {
    const load = async () => {
      try {
        const [empResponse, deptResponse, skillResponse] = await Promise.all([
          api.get('/employees'),
          api.get('/departments'),
          api.get('/skills'),
        ]);
        const mapped = empResponse.data.map(emp => ({
          ...emp,
          skills: emp.skills.map(s => s.skill_name),
        }));
        setEmployees(mapped);
        setDepartments(deptResponse.data);
        setSkills(skillResponse.data);
      } catch (err) {
        console.warn('Employees API unavailable, using demo data');
      }
    };
    load();
  }, []);

  const filteredEmployees = useMemo(() => {
    const query = search.toLowerCase();
    return employees.filter(emp =>
      emp.name.toLowerCase().includes(query) || emp.department_name?.toLowerCase().includes(query)
    );
  }, [employees, search]);

  const handleChange = e => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  const toggleSkill = id => {
    setForm(prev => ({
      ...prev,
      skill_ids: prev.skill_ids.includes(id) ? prev.skill_ids.filter(item => item !== id) : [...prev.skill_ids, id],
    }));
  };

  const handleAdd = async e => {
    e.preventDefault();
    setError('');
    if (!form.name || !form.email) {
      setError('Name and email are required');
      return;
    }
    try {
      const payload = { ...form, department_id: Number(form.department_id), salary: Number(form.salary), skill_ids: form.skill_ids };
      const response = await api.post('/employees', payload);
      setEmployees(prev => [...prev, { ...form, employee_id: response.data.employee_id, skills: skills.filter(skill => form.skill_ids.includes(skill.id)).map(item => item.skill_name), department_name: departments.find(d => d.id === Number(form.department_id))?.department_name || '' }]);
      setForm({ name: '', email: '', department_id: '', designation: '', salary: '', phone: '', address: '', skill_ids: [] });
      setShowForm(false);
    } catch (err) {
      setError(err.response?.data?.error || 'Unable to add employee');
    }
  };

  return (
    <div className="page fade-up">
      <div className="page-header">
        <div>
          <h2>Employee directory</h2>
          <p className="muted">Add, manage, and review your team profiles.</p>
        </div>
        <Btn onClick={() => setShowForm(open => !open)}>{showForm ? 'Close form' : 'Add Employee'}</Btn>
      </div>

      {showForm && (
        <Card className="form-card">
          <form onSubmit={handleAdd} className="form-grid">
            <label>
              Full name
              <input name="name" value={form.name} onChange={handleChange} />
            </label>
            <label>
              Email address
              <input name="email" value={form.email} onChange={handleChange} />
            </label>
            <label>
              Department
              <select name="department_id" value={form.department_id} onChange={handleChange}>
                <option value="">Select</option>
                {departments.map(dep => <option key={dep.id} value={dep.id}>{dep.department_name}</option>)}
              </select>
            </label>
            <label>
              Designation
              <input name="designation" value={form.designation} onChange={handleChange} />
            </label>
            <label>
              Salary
              <input name="salary" type="number" value={form.salary} onChange={handleChange} />
            </label>
            <label>
              Phone
              <input name="phone" value={form.phone} onChange={handleChange} />
            </label>
            <label className="full-width">
              Address
              <textarea name="address" value={form.address} onChange={handleChange} />
            </label>
            <div className="full-width">
              <div className="section-label">Skills</div>
              <div className="skill-grid">
                {skills.map(skill => (
                  <button type="button" key={skill.id} className={`pill ${form.skill_ids.includes(skill.id) ? 'pill-active' : ''}`} onClick={() => toggleSkill(skill.id)}>
                    {skill.skill_name}
                  </button>
                ))}
              </div>
            </div>
            {error && <div className="form-error">{error}</div>}
            <div className="form-actions">
              <Btn type="submit">Create employee</Btn>
            </div>
          </form>
        </Card>
      )}

      <div className="toolbar">
        <input className="search-input" placeholder="Search by name or department" value={search} onChange={e => setSearch(e.target.value)} />
      </div>
      <div className="grid grid-cols-3 gap">
        {filteredEmployees.map(emp => (
          <Card key={emp.employee_id} className="employee-card">
            <div className="card-top">
              <div className="avatar-circle small">{emp.name.split(' ').map(w => w[0]).join('').slice(0, 2)}</div>
              <div>
                <h3>{emp.name}</h3>
                <div className="muted">{emp.designation}</div>
              </div>
              <Badge label={emp.department_name} />
            </div>
            <div className="employee-details">
              <div><strong>Email:</strong> {emp.email}</div>
              <div><strong>Phone:</strong> {emp.phone}</div>
              <div><strong>Salary:</strong> ${emp.salary}</div>
            </div>
            <div className="skill-wrap">
              {emp.skills?.map(skill => <span key={skill} className="chip">{skill}</span>)}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default EmployeesPage;
