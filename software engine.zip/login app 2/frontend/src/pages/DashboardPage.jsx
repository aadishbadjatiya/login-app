import { useEffect, useState } from 'react';
import useAuth from '../hooks/useAuth.jsx';
import api from '../services/api.js';
import StatCard from '../components/StatCard.jsx';
import Badge from '../components/Badge.jsx';
import { demoLeaves } from '../data/demo.js';

const DashboardPage = () => {
  const { state } = useAuth();
  const [summary, setSummary] = useState({ totalEmployees: 12, totalDepartments: 5, totalLeaves: 23, pendingLeaves: 4, totalAssets: 0, allocatedAssets: 0 });
  const [requests, setRequests] = useState(demoLeaves);

  useEffect(() => {
    const load = async () => {
      try {
        const response = await api.get('/reports/summary');
        setSummary(response.data);
        const leaves = await api.get('/leaves');
        setRequests(leaves.data.slice(0, 4));
      } catch (err) {
        console.warn('Dashboard API unavailable, using demo data');
      }
    };
    load();
  }, []);

  const firstName = state.user?.name.split(' ')[0] || 'Team';

  return (
    <div className="page fade-up">
      <div className="page-header">
        <div>
          <h2>Welcome back, {firstName}</h2>
          <p className="muted">Your HR overview is ready.</p>
        </div>
      </div>
      <div className="grid gap">
        <StatCard title="Total Employees" value={summary.totalEmployees} accent="#4a7c59" />
        <StatCard title="Departments" value={summary.totalDepartments} accent="#1f6aa5" />
        <StatCard title="Allocated Assets" value={summary.allocatedAssets} accent="#d4820a" />
        <StatCard title="Total Leaves" value={summary.totalLeaves} accent="#c0392b" />
      </div>
      <div className="grid gap">
        <StatCard title="Total Assets" value={summary.totalAssets} accent="#5a5acd" />
        <StatCard title="Available Assets" value={summary.totalAssets - summary.allocatedAssets} accent="#2a9d8f" />
        <StatCard title="Pending Leaves" value={summary.pendingLeaves} accent="#f39c12" />
        <StatCard title="Resolved Leaves" value={summary.totalLeaves - summary.pendingLeaves} accent="#16a085" />
      </div>
      <div className="grid gap-two">
        <div className="card chart-card fade-up">
          <div className="card-title">Department workload</div>
          <div className="bar-chart">
            <div><span className="bar-label">IT</span><div className="bar" style={{ width: '84%' }} /></div>
            <div><span className="bar-label">Marketing</span><div className="bar" style={{ width: '68%' }} /></div>
            <div><span className="bar-label">HR</span><div className="bar" style={{ width: '53%' }} /></div>
          </div>
        </div>
        <div className="card">
          <div className="card-title">Recent leave requests</div>
          <div className="list-stack">
            {requests.map(item => (
              <div key={item.id} className="notification-card">
                <div>
                  <strong>{item.employee_name}</strong>
                  <div className="muted small">{item.leave_name} • {item.from_date} → {item.to_date}</div>
                </div>
                <Badge label={item.status} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;
