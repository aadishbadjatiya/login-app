import { useEffect, useMemo, useState } from 'react';
import useAuth from '../hooks/useAuth.jsx';
import api from '../services/api.js';
import Btn from '../components/Btn.jsx';
import Badge from '../components/Badge.jsx';
import { demoLeaves } from '../data/demo.js';

const LeaveTabs = ['All', 'Pending', 'Approved', 'Rejected'];

const LeavesPage = () => {
  const { state } = useAuth();
  const [leaves, setLeaves] = useState(demoLeaves);
  const [activeTab, setActiveTab] = useState('All');
  const [openForm, setOpenForm] = useState(false);
  const [form, setForm] = useState({ employee_id: '', leave_type_id: '', from_date: '', to_date: '', reason: '' });
  const [error, setError] = useState('');

  useEffect(() => {
    const load = async () => {
      try {
        const response = await api.get('/leaves');
        setLeaves(response.data);
      } catch (err) {
        console.warn('Leaves API unavailable, using demo data');
      }
    };
    load();
  }, []);

  const filteredLeaves = useMemo(() => {
    return leaves.filter(item => activeTab === 'All' || item.status === activeTab);
  }, [leaves, activeTab]);

  const handleChange = e => setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));

  const applyLeave = async e => {
    e.preventDefault();
    setError('');
    try {
      await api.post('/leaves', form);
      setLeaves(prev => [
        { id: Date.now(), employee_name: 'Pending user', leave_name: 'Casual', from_date: form.from_date, to_date: form.to_date, total_days: 1, reason: form.reason, status: 'Pending' },
        ...prev,
      ]);
      setForm({ employee_id: '', leave_type_id: '', from_date: '', to_date: '', reason: '' });
      setOpenForm(false);
    } catch (err) {
      setError(err.response?.data?.error || 'Unable to apply leave');
    }
  };

  const actionLeave = async (id, action) => {
    try {
      await api.put(`/leaves/${id}/approve`, { action, remarks: `${action} by ${state.user.role}` });
      setLeaves(prev => prev.map(item => item.id === id ? { ...item, status: action } : item));
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="page fade-up">
      <div className="page-header">
        <div>
          <h2>Leave management</h2>
          <p className="muted">Track approvals and submit leave requests.</p>
        </div>
        <Btn onClick={() => setOpenForm(flag => !flag)}>{openForm ? 'Hide form' : 'Apply leave'}</Btn>
      </div>

      {openForm && (
        <div className="card form-card">
          <form onSubmit={applyLeave} className="form-grid">
            <label>
              Employee ID
              <input name="employee_id" value={form.employee_id} onChange={handleChange} placeholder="e.g. 101" />
            </label>
            <label>
              Leave type
              <select name="leave_type_id" value={form.leave_type_id} onChange={handleChange}>
                <option value="">Choose</option>
                <option value="1">Casual</option>
                <option value="2">Sick</option>
                <option value="3">Earned</option>
                <option value="4">Maternity</option>
              </select>
            </label>
            <label>
              From date
              <input type="date" name="from_date" value={form.from_date} onChange={handleChange} />
            </label>
            <label>
              To date
              <input type="date" name="to_date" value={form.to_date} onChange={handleChange} />
            </label>
            <label className="full-width">
              Reason
              <textarea name="reason" value={form.reason} onChange={handleChange} />
            </label>
            {error && <div className="form-error">{error}</div>}
            <div className="form-actions">
              <Btn type="submit">Submit request</Btn>
            </div>
          </form>
        </div>
      )}

      <div className="tabs">
        {LeaveTabs.map(tab => (
          <button key={tab} className={`tab ${tab === activeTab ? 'tab-active' : ''}`} onClick={() => setActiveTab(tab)}>{tab}</button>
        ))}
      </div>
      <div className="table-card">
        <div className="table-row table-header">
          <div>Employee</div>
          <div>Type</div>
          <div>Dates</div>
          <div>Days</div>
          <div>Reason</div>
          <div>Status</div>
          <div>Actions</div>
        </div>
        {filteredLeaves.map(item => (
          <div key={item.id} className="table-row">
            <div>{item.employee_name}</div>
            <div>{item.leave_name}</div>
            <div>{item.from_date} → {item.to_date}</div>
            <div>{item.total_days}</div>
            <div>{item.reason}</div>
            <div><Badge label={item.status} /></div>
            <div className="action-buttons">
              {['Admin', 'HR', 'Manager'].includes(state.user.role) && item.status === 'Pending' ? (
                <>
                  <Btn variant="success" onClick={() => actionLeave(item.id, 'Approved')}>✓</Btn>
                  <Btn variant="danger" onClick={() => actionLeave(item.id, 'Rejected')}>✕</Btn>
                </>
              ) : (
                <span className="muted">—</span>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default LeavesPage;
