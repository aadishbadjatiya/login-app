import { useEffect, useState } from 'react';
import useAuth from '../hooks/useAuth.jsx';
import api from '../services/api.js';
import Card from '../components/Card.jsx';
import Avatar from '../components/Avatar.jsx';

const ProfilePage = () => {
  const { state } = useAuth();
  const [profile, setProfile] = useState(state.user || { name: '', email: '', role: '' });

  useEffect(() => {
    const load = async () => {
      try {
        const response = await api.get('/user/profile');
        setProfile(response.data);
      } catch (err) {
        console.warn('Profile API unavailable, using cached profile');
      }
    };
    load();
  }, []);

  return (
    <div className="page fade-up">
      <div className="page-header">
        <div>
          <h2>My profile</h2>
          <p className="muted">Review your account and active session details.</p>
        </div>
      </div>
      <Card className="profile-card">
        <div className="profile-grid">
          <div className="profile-avatar"><Avatar name={profile.name || 'User'} size={96} /></div>
          <div className="profile-details">
            <div><strong>Name:</strong> {profile.name}</div>
            <div><strong>Email:</strong> {profile.email}</div>
            <div><strong>Role:</strong> {profile.role}</div>
            <div><strong>User ID:</strong> {profile.id || 'N/A'}</div>
            <div><strong>Session:</strong> Active</div>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default ProfilePage;
