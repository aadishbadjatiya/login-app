import { useEffect, useMemo, useState } from 'react';
import api from '../services/api.js';
import Btn from '../components/Btn.jsx';
import Card from '../components/Card.jsx';
import Badge from '../components/Badge.jsx';
import FormInput from '../components/FormInput.jsx';
import FormSelect from '../components/FormSelect.jsx';
import { exportToCsv, exportToExcel } from '../utils/exporter.js';

const assetStatusOptions = [
  { value: 'Available', label: 'Available' },
  { value: 'Allocated', label: 'Allocated' },
  { value: 'Returned', label: 'Returned' },
  { value: 'Damaged', label: 'Damaged' },
  { value: 'Lost', label: 'Lost' },
];

const AssetsPage = () => {
  const [assets, setAssets] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ asset_code: '', asset_name: '', asset_type: '', purchase_date: '', purchase_cost: '', status: 'Available' });
  const [assignState, setAssignState] = useState({ employee_id: '', return_date: '' });
  const [selectedAsset, setSelectedAsset] = useState(null);
  const [message, setMessage] = useState('');

  useEffect(() => {
    const load = async () => {
      try {
        const [assetRes, employeeRes] = await Promise.all([api.get('/assets'), api.get('/employees')]);
        setAssets(assetRes.data);
        setEmployees(employeeRes.data);
      } catch (err) {
        console.warn('Assets API unavailable');
      }
    };
    load();
  }, []);

  const counts = useMemo(() => ({
    total: assets.length,
    allocated: assets.filter(asset => asset.status === 'Allocated').length,
    available: assets.filter(asset => asset.status === 'Available').length,
    returned: assets.filter(asset => asset.status === 'Returned').length,
  }), [assets]);

  const handleChange = e => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  const onExportAssets = async format => {
    setMessage('');
    try {
      const response = await api.get('/reports/export/assets');
      if (format === 'excel') {
        exportToExcel(response.data, 'asset-report');
      } else {
        exportToCsv(response.data, 'asset-report');
      }
    } catch (err) {
      setMessage('Unable to download asset report');
    }
  };

  const handleFormSubmit = async e => {
    e.preventDefault();
    setMessage('');
    setLoading(true);
    try {
      const payload = { ...form, purchase_cost: Number(form.purchase_cost) };
      const response = await api.post('/assets', payload);
      setAssets(prev => [...prev, response.data]);
      setForm({ asset_code: '', asset_name: '', asset_type: '', purchase_date: '', purchase_cost: '', status: 'Available' });
      setShowForm(false);
    } catch (err) {
      setMessage(err.response?.data?.error || 'Could not create asset');
    } finally {
      setLoading(false);
    }
  };

  const handleAssign = asset => {
    setSelectedAsset(asset);
    setAssignState({ employee_id: '', return_date: '' });
    setMessage('');
  };

  const submitAssignment = async e => {
    e.preventDefault();
    if (!selectedAsset) return;
    setLoading(true);
    setMessage('');
    try {
      await api.post(`/assets/${selectedAsset.id}/assign`, {
        employee_id: Number(assignState.employee_id),
        return_date: assignState.return_date || null,
      });
      setAssets(prev => prev.map(asset => asset.id === selectedAsset.id ? { ...asset, status: 'Allocated' } : asset));
      setSelectedAsset(null);
      setMessage('Asset assigned successfully');
    } catch (err) {
      setMessage(err.response?.data?.error || 'Unable to assign asset');
    } finally {
      setLoading(false);
    }
  };

  const handleReturn = async asset => {
    setLoading(true);
    setMessage('');
    try {
      await api.post(`/assets/${asset.id}/return`, { remarks: 'Returned to inventory' });
      setAssets(prev => prev.map(item => item.id === asset.id ? { ...item, status: 'Available' } : item));
      setMessage('Asset returned');
    } catch (err) {
      setMessage(err.response?.data?.error || 'Unable to return asset');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page fade-up">
      <div className="page-header">
        <div>
          <h2>Asset management</h2>
          <p className="muted">Track hardware, licenses, and allocation lifecycle.</p>
        </div>
        <div className="header-actions">
          <Btn variant="secondary" onClick={() => onExportAssets('excel')}>Export Excel</Btn>
          <Btn variant="secondary" onClick={() => onExportAssets('csv')}>Export CSV</Btn>
          <Btn onClick={() => setShowForm(open => !open)}>{showForm ? 'Close asset form' : 'Add new asset'}</Btn>
        </div>
      </div>

      <div className="grid gap">
        <Card title="Inventory overview">
          <div className="grid grid-cols-4 gap-small">
            <div className="stat-item"><strong>{counts.total}</strong><div className="muted">Total assets</div></div>
            <div className="stat-item"><strong>{counts.allocated}</strong><div className="muted">Allocated</div></div>
            <div className="stat-item"><strong>{counts.available}</strong><div className="muted">Available</div></div>
            <div className="stat-item"><strong>{counts.returned}</strong><div className="muted">Returned</div></div>
          </div>
        </Card>
      </div>

      {showForm && (
        <Card className="form-card">
          <form onSubmit={handleFormSubmit} className="form-grid">
            <FormInput label="Asset code" name="asset_code" value={form.asset_code} onChange={handleChange} required />
            <FormInput label="Asset name" name="asset_name" value={form.asset_name} onChange={handleChange} required />
            <FormInput label="Asset type" name="asset_type" value={form.asset_type} onChange={handleChange} required />
            <FormInput label="Purchase date" name="purchase_date" type="date" value={form.purchase_date} onChange={handleChange} required />
            <FormInput label="Purchase cost" name="purchase_cost" type="number" value={form.purchase_cost} onChange={handleChange} required />
            <FormSelect label="Status" name="status" value={form.status} options={assetStatusOptions} onChange={handleChange} required />
            {message && <div className="form-error">{message}</div>}
            <div className="form-actions"><Btn type="submit" disabled={loading}>{loading ? 'Saving...' : 'Save asset'}</Btn></div>
          </form>
        </Card>
      )}

      <div className="asset-grid">
        {assets.map(asset => (
          <Card key={asset.id} className="asset-card">
            <div className="card-top">
              <div>
                <h3>{asset.asset_name}</h3>
                <div className="muted">{asset.asset_type}</div>
              </div>
              <Badge label={asset.status || 'Available'} />
            </div>
            <div className="asset-details">
              <div><strong>Code:</strong> {asset.asset_code}</div>
              <div><strong>Cost:</strong> ${asset.purchase_cost}</div>
              <div><strong>Owned by:</strong> {asset.employee_name || 'Unassigned'}</div>
              <div><strong>Allocated:</strong> {asset.allocated_date || '—'}</div>
              <div><strong>Return date:</strong> {asset.return_date || '—'}</div>
            </div>
            <div className="card-actions">
              {asset.status !== 'Allocated' ? (
                <Btn variant="secondary" onClick={() => handleAssign(asset)}>Assign</Btn>
              ) : (
                <Btn variant="secondary" onClick={() => handleReturn(asset)}>Return</Btn>
              )}
            </div>
          </Card>
        ))}
      </div>

      {selectedAsset && (
        <Card className="form-card">
          <h3>Assign {selectedAsset.asset_name}</h3>
          <form onSubmit={submitAssignment} className="form-grid">
            <FormSelect
              label="Employee"
              name="employee_id"
              value={assignState.employee_id}
              onChange={e => setAssignState(prev => ({ ...prev, employee_id: e.target.value }))}
              options={employees.map(emp => ({ value: emp.profile_id, label: emp.name }))}
              required
            />
            <FormInput
              label="Return date"
              name="return_date"
              type="date"
              value={assignState.return_date}
              onChange={e => setAssignState(prev => ({ ...prev, return_date: e.target.value }))}
            />
            {message && <div className="form-error">{message}</div>}
            <div className="form-actions">
              <Btn type="submit" disabled={loading}>{loading ? 'Assigning...' : 'Assign asset'}</Btn>
              <Btn type="button" variant="ghost" onClick={() => setSelectedAsset(null)}>Cancel</Btn>
            </div>
          </form>
        </Card>
      )}
    </div>
  );
};

export default AssetsPage;
