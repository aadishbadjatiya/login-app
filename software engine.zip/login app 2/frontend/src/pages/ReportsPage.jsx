import { useEffect, useState } from 'react';
import useAuth from '../hooks/useAuth.jsx';
import api from '../services/api.js';
import Card from '../components/Card.jsx';
import Badge from '../components/Badge.jsx';
import Btn from '../components/Btn.jsx';
import { exportToCsv, exportToExcel } from '../utils/exporter.js';

const ReportsPage = () => {
  const { state } = useAuth();
  const [summary, setSummary] = useState({ totalEmployees: 10, totalDepartments: 5, totalLeaves: 18, pendingLeaves: 3, totalAssets: 0, allocatedAssets: 0 });
  const [departmentLeave, setDepartmentLeave] = useState([]);
  const [trend, setTrend] = useState([]);
  const [mostAbsent, setMostAbsent] = useState({ name: 'Amina Patel', department_name: 'IT', absent_days: 25 });
  const [exportMessage, setExportMessage] = useState('');

  useEffect(() => {
    const load = async () => {
      try {
        const [summaryRes, deptRes, trendRes, absentRes] = await Promise.all([
          api.get('/reports/summary'),
          api.get('/reports/department-leave'),
          api.get('/reports/monthly-trend'),
          api.get('/reports/most-absent'),
        ]);
        setSummary(summaryRes.data);
        setDepartmentLeave(deptRes.data);
        setTrend(trendRes.data);
        setMostAbsent(absentRes.data);
      } catch (err) {
        console.warn('Reports API unavailable, using demo data');
      }
    };
    if (['Admin', 'HR'].includes(state.user.role)) load();
  }, [state.user.role]);

  const onExport = async type => {
    setExportMessage('');
    try {
      const response = await api.get(`/reports/export/${type}`);
      if (type === 'employees') {
        exportToExcel(response.data, 'employee-report');
      } else if (type === 'leaves') {
        exportToExcel(response.data, 'leave-report');
      } else if (type === 'assets') {
        exportToExcel(response.data, 'asset-report');
      }
    } catch (err) {
      setExportMessage('Unable to download report');
    }
  };

  const onExportCsv = async type => {
    setExportMessage('');
    try {
      const response = await api.get(`/reports/export/${type}`);
      exportToCsv(response.data, `${type}-report`);
    } catch (err) {
      setExportMessage('Unable to download CSV');
    }
  };

  if (!['Admin', 'HR'].includes(state.user.role)) {
    return (
      <div className="page fade-up">
        <div className="page-header">
          <h2>Reports</h2>
          <p className="muted">Admin and HR only.</p>
        </div>
        <div className="card">
          <p>You do not have permission to view this report center.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="page fade-up">
      <div className="page-header">
        <div>
          <h2>Reports dashboard</h2>
          <p className="muted">Leave summaries, department insights, and absence trends.</p>
        </div>
        <div className="header-actions">
          <Btn variant="secondary" onClick={() => onExport('employees')}>Download Employee XLSX</Btn>
          <Btn variant="secondary" onClick={() => onExport('assets')}>Download Asset XLSX</Btn>
          <Btn variant="secondary" onClick={() => onExportCsv('leaves')}>Download Leave CSV</Btn>
        </div>
      </div>
      {exportMessage && <div className="form-error">{exportMessage}</div>}
      <div className="grid gap">
        <Card title="Leave status summary">
          <div className="grid grid-cols-3 gap-small">
            <div className="stat-item"><strong>{summary.pendingLeaves}</strong><div className="muted">Pending</div></div>
            <div className="stat-item"><strong>{summary.totalLeaves - summary.pendingLeaves}</strong><div className="muted">Resolved</div></div>
            <div className="stat-item"><strong>{summary.totalEmployees}</strong><div className="muted">Employees</div></div>
          </div>
        </Card>
        <Card title="Asset inventory">
          <div className="grid grid-cols-3 gap-small">
            <div className="stat-item"><strong>{summary.totalAssets}</strong><div className="muted">Total assets</div></div>
            <div className="stat-item"><strong>{summary.allocatedAssets}</strong><div className="muted">Allocated</div></div>
            <div className="stat-item"><strong>{summary.totalAssets - summary.allocatedAssets}</strong><div className="muted">Available</div></div>
          </div>
        </Card>
        <Card title="Most absent">
          <div className="most-absent-card">
            <strong>{mostAbsent.name}</strong>
            <div className="muted">{mostAbsent.department_name}</div>
            <div className="large-value">{mostAbsent.absent_days} days</div>
          </div>
        </Card>
      </div>
      <div className="grid gap-two">
        <Card title="Leave by department">
          <div className="table-row table-header">
            <div>Department</div>
            <div>Approved</div>
            <div>Pending</div>
            <div>Rejected</div>
          </div>
          {departmentLeave.map(row => (
            <div key={row.department_name} className="table-row">
              <div>{row.department_name}</div>
              <div>{row.approved}</div>
              <div>{row.pending}</div>
              <div>{row.rejected}</div>
            </div>
          ))}
        </Card>
        <Card title="Monthly leave trend">
          <div className="trend-list">
            {trend.map(row => (
              <div key={row.month} className="trend-item">
                <span>{row.month}</span>
                <span>{row.total_days} days</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
};

export default ReportsPage;
