import { useEffect, useState } from 'react';
import api from '../services/api.js';
import Card from '../components/Card.jsx';
import Btn from '../components/Btn.jsx';
import Badge from '../components/Badge.jsx';

const NotificationsPage = () => {
  const [notifications, setNotifications] = useState([]);
  const [message, setMessage] = useState('');

  useEffect(() => {
    const load = async () => {
      try {
        const response = await api.get('/notifications');
        setNotifications(response.data);
      } catch (err) {
        setMessage('Unable to load notifications');
      }
    };
    load();
  }, []);

  const markRead = async id => {
    try {
      await api.put(`/notifications/${id}/read`);
      setNotifications(prev => prev.map(note => note.id === id ? { ...note, is_read: true } : note));
    } catch (err) {
      setMessage('Unable to update notification');
    }
  };

  const markAll = async () => {
    try {
      await api.put('/notifications/read-all');
      setNotifications(prev => prev.map(note => ({ ...note, is_read: true })));
    } catch (err) {
      setMessage('Unable to mark notifications read');
    }
  };

  return (
    <div className="page fade-up">
      <div className="page-header">
        <div>
          <h2>Notifications</h2>
          <p className="muted">A timeline of approvals, assignments, and system alerts.</p>
        </div>
        <Btn variant="secondary" onClick={markAll}>Mark all as read</Btn>
      </div>

      {message && <div className="form-error">{message}</div>}

      <div className="notification-list">
        {notifications.length === 0 && (
          <Card><p>No notifications yet.</p></Card>
        )}

        {notifications.map(note => (
          <Card key={note.id} className={note.is_read ? '' : 'notification-new'}>
            <div className="card-top">
              <div>
                <h3>{note.title}</h3>
                <p className="muted small">{new Date(note.created_at).toLocaleString()}</p>
              </div>
              <Badge label={note.is_read ? 'Read' : 'New'} />
            </div>
            <p>{note.message}</p>
            {!note.is_read && (
              <div className="card-actions"><Btn variant="secondary" onClick={() => markRead(note.id)}>Mark read</Btn></div>
            )}
          </Card>
        ))}
      </div>
    </div>
  );
};

export default NotificationsPage;
