import { useEffect, useState } from 'react';
import api from '../services/api.js';
import Card from '../components/Card.jsx';
import { demoDepartments, demoEmployees } from '../data/demo.js';

const iconMap = {
  IT: '💻',
  Marketing: '📣',
  HR: '🤝',
  Finance: '💰',
  Operations: '⚙️',
};

const DepartmentsPage = () => {
  const [departments, setDepartments] = useState(demoDepartments);
  const [employees, setEmployees] = useState(demoEmployees);

  useEffect(() => {
    const load = async () => {
      try {
        const response = await api.get('/departments');
        setDepartments(response.data);
      } catch (err) {
        console.warn('Departments API unavailable, using demo data');
      }
    };
    load();
  }, []);

  const groups = departments.map(dep => ({
    ...dep,
    members: employees.filter(emp => emp.department_name === dep.department_name),
  }));

  return (
    <div className="page fade-up">
      <div className="page-header">
        <div>
          <h2>Departments</h2>
          <p className="muted">Monitor each team and their employee count.</p>
        </div>
      </div>
      <div className="grid grid-cols-3 gap">
        {groups.map(dep => (
          <Card key={dep.id} className="dept-card">
            <div className="dept-card-header">
              <div className="dept-icon">{iconMap[dep.department_name] || '🏢'}</div>
              <div>
                <h3>{dep.department_name}</h3>
                <p className="muted">{dep.members.length} employees</p>
              </div>
            </div>
            <div className="chip-wrap">
              {dep.members.slice(0, 5).map(member => (
                <span key={member.employee_id} className="chip">{member.name}</span>
              ))}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default DepartmentsPage;
