import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api.js';
import useAuth from '../hooks/useAuth.jsx';
import { demoUsers } from '../data/demo.js';
import Btn from '../components/Btn.jsx';

const LoginPage = () => {
  const { state, login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (state.user && state.token) {
      navigate('/dashboard');
    }
  }, [state, navigate]);

  const handleSubmit = async event => {
    event.preventDefault();
    setError('');
    try {
      const response = await api.post('/auth/login', { email, password });
      login(response.data);
      navigate('/dashboard');
    } catch (err) {
      const match = demoUsers.find(user => user.email === email && user.password === password);
      if (match) {
        login({ user: { id: match.id, name: match.name, email: match.email, role: match.role }, accessToken: 'demo-token', refreshToken: 'demo-refresh' });
        navigate('/dashboard');
        return;
      }
      setError(err.response?.data?.error || 'Unable to login');
    }
  };

  const quickLogin = demo => {
    setEmail(demo.email);
    setPassword(demo.password);
  };

  return (
    <div className="page grid-two-col fade-up">
      <section className="panel brand-panel">
        <div>
          <div className="brand-logo-large">WorkForce</div>
          <p className="brand-copy">HR operations, payroll, approvals, and people analytics in one dashboard.</p>
        </div>
        <div className="quick-login">
          <p className="muted">Quick login demo users</p>
          <div className="quick-buttons">
            {demoUsers.map(user => (
              <button type="button" key={user.email} className="btn btn-ghost" onClick={() => quickLogin(user)}>
                {user.role}
              </button>
            ))}
          </div>
        </div>
      </section>
      <section className="panel form-panel">
        <div className="card">
          <h1>Sign into WorkForce</h1>
          <p className="muted">Enter your company credentials to continue.</p>
          <form onSubmit={handleSubmit} className="form-stack">
            <label>
              Email
              <input value={email} onChange={e => setEmail(e.target.value)} placeholder="email@company.com" />
            </label>
            <label>
              Password
              <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" />
            </label>
            {error && <div className="form-error">{error}</div>}
            <Btn type="submit">Login</Btn>
          </form>
        </div>
      </section>
    </div>
  );
};

export default LoginPage;
