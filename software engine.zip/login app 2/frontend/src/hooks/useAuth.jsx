import { useContext } from 'react';
import AuthContext from '../context/AuthContext.jsx';

const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return {
    ...context,
    login: payload => context.dispatch({ type: 'LOGIN', payload }),
    logout: () => context.dispatch({ type: 'LOGOUT' }),
  };
};

export default useAuth;
