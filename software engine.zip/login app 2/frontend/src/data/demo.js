export const demoUsers = [
  { id: 1, name: 'Admin User', email: 'admin@company.com', password: 'admin123', role: 'Admin' },
  { id: 2, name: 'HR Manager', email: 'hr@company.com', password: 'hr123', role: 'HR' },
  { id: 3, name: 'Team Manager', email: 'manager@company.com', password: 'mgr123', role: 'Manager' },
  { id: 4, name: 'Employee One', email: 'emp@company.com', password: 'emp123', role: 'Employee' },
];

export const demoDepartments = [
  { id: 1, department_name: 'IT' },
  { id: 2, department_name: 'Marketing' },
  { id: 3, department_name: 'HR' },
];

export const demoSkills = [
  { id: 1, skill_name: 'React' },
  { id: 2, skill_name: 'Node.js' },
  { id: 3, skill_name: 'PostgreSQL' },
  { id: 4, skill_name: 'AWS' },
];

export const demoEmployees = [
  {
    employee_id: 101,
    name: 'Amina Patel',
    email: 'amina@company.com',
    designation: 'Frontend Engineer',
    department_name: 'IT',
    phone: '555-0134',
    address: '221 B Street',
    salary: 84000,
    skills: ['React', 'PostgreSQL'],
    images: [],
  },
  {
    employee_id: 102,
    name: 'Lena Jacobs',
    email: 'lena@company.com',
    designation: 'Marketing Lead',
    department_name: 'Marketing',
    phone: '555-0189',
    address: '311 D Avenue',
    salary: 76000,
    skills: ['Figma'],
    images: [],
  },
  {
    employee_id: 103,
    name: 'Ravi Singh',
    email: 'ravi@company.com',
    designation: 'HR Business Partner',
    department_name: 'HR',
    phone: '555-0223',
    address: '84 Elm Street',
    salary: 72000,
    skills: ['Python'],
    images: [],
  },
];

export const demoLeaves = [
  {
    id: 201,
    employee_name: 'Amina Patel',
    leave_name: 'Casual',
    from_date: '2026-06-10',
    to_date: '2026-06-12',
    total_days: 3,
    reason: 'Conference travel',
    status: 'Pending',
  },
  {
    id: 202,
    employee_name: 'Lena Jacobs',
    leave_name: 'Sick',
    from_date: '2026-06-02',
    to_date: '2026-06-03',
    total_days: 2,
    reason: 'Medical check-up',
    status: 'Approved',
  },
  {
    id: 203,
    employee_name: 'Ravi Singh',
    leave_name: 'Earned',
    from_date: '2026-06-18',
    to_date: '2026-06-20',
    total_days: 3,
    reason: 'Family time',
    status: 'Pending',
  },
];
