const palette = {
  Pending: '#d4820a',
  Approved: '#4a7c59',
  Rejected: '#c0392b',
  Admin: '#c0392b',
  HR: '#4a7c59',
  Manager: '#d4820a',
  Employee: '#1f6aa5',
};

const Badge = ({ label }) => {
  return (
    <span className="badge" style={{ backgroundColor: palette[label] || '#555' }}>
      {label}
    </span>
  );
};

export default Badge;
