const StatCard = ({ title, value, accent }) => (
  <div className="stat-card" style={{ borderColor: accent }}>
    <div className="stat-title">{title}</div>
    <div className="stat-value">{value}</div>
  </div>
);

export default StatCard;
