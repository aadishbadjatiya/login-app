const Card = ({ title, children, className = '' }) => (
  <section className={`card ${className}`}>
    {title && <div className="card-title">{title}</div>}
    {children}
  </section>
);

export default Card;
