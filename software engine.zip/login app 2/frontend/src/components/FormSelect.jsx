const FormSelect = ({ label, name, value, options, onChange, required = false, ...props }) => (
  <label className="form-field">
    <span>{label}</span>
    <select name={name} value={value} onChange={onChange} required={required} {...props}>
      <option value="">Select</option>
      {options.map(option => (
        <option key={option.value} value={option.value}>{option.label}</option>
      ))}
    </select>
  </label>
);

export default FormSelect;
