const Avatar = ({ name, size = 72 }) => {
  const initials = name
    .split(' ')
    .map(part => part[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
  return (
    <div className="avatar-circle" style={{ width: size, height: size, fontSize: size / 2.8 }}>
      {initials}
    </div>
  );
};

export default Avatar;
