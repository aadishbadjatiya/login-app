const FormInput = ({ label, name, value, type = 'text', onChange, required = false, ...props }) => (
  <label className="form-field">
    <span>{label}</span>
    <input
      name={name}
      type={type}
      value={value}
      onChange={onChange}
      required={required}
      {...props}
    />
  </label>
);

export default FormInput;
