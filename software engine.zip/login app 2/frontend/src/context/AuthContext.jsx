import { createContext, useReducer, useEffect } from 'react';

const initialState = {
  user: null,
  token: localStorage.getItem('wf_token') || null,
  refreshToken: localStorage.getItem('wf_refresh') || null,
};

const AuthContext = createContext(initialState);

const reducer = (state, action) => {
  switch (action.type) {
    case 'LOGIN':
      return { user: action.payload.user, token: action.payload.accessToken, refreshToken: action.payload.refreshToken };
    case 'LOGOUT':
      return { user: null, token: null, refreshToken: null };
    default:
      return state;
  }
};

export const AuthProvider = ({ children }) => {
  const [state, dispatch] = useReducer(reducer, initialState);

  useEffect(() => {
    if (state.token) {
      localStorage.setItem('wf_token', state.token);
      localStorage.setItem('wf_user', JSON.stringify(state.user));
      localStorage.setItem('wf_refresh', state.refreshToken || '');
    } else {
      localStorage.removeItem('wf_token');
      localStorage.removeItem('wf_refresh');
      localStorage.removeItem('wf_user');
    }
  }, [state.token, state.user, state.refreshToken]);

  useEffect(() => {
    const storedUser = localStorage.getItem('wf_user');
    if (storedUser && !state.user) {
      dispatch({ type: 'LOGIN', payload: { user: JSON.parse(storedUser), accessToken: state.token, refreshToken: state.refreshToken } });
    }
  }, []);

  return <AuthContext.Provider value={{ state, dispatch }}>{children}</AuthContext.Provider>;
};

export default AuthContext;
