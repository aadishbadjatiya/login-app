const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const authorize = require('../middleware/authorize');
const {
  list,
  getById,
  create,
  update,
  remove,
  uploadImages,
} = require('../controllers/employeeController');

router.get('/', auth, list);
router.get('/:id', auth, getById);
router.post('/', auth, authorize('Admin', 'HR'), create);
router.put('/:id', auth, authorize('Admin', 'HR'), update);
router.delete('/:id', auth, authorize('Admin'), remove);
router.post('/upload', auth, authorize('Admin', 'HR'), uploadImages);

module.exports = router;
