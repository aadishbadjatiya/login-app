const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const authorize = require('../middleware/authorize');
const {
  list,
  types,
  balance,
  apply,
  approve,
  history,
} = require('../controllers/leaveController');

router.get('/', auth, list);
router.get('/types', auth, types);
router.get('/balance/:employee_id', auth, balance);
router.post('/', auth, apply);
router.put('/:id/approve', auth, authorize('Admin', 'HR', 'Manager'), approve);
router.get('/:id/history', auth, history);

module.exports = router;
