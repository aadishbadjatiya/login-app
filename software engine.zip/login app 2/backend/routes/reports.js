const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const authorize = require('../middleware/authorize');
const {
  summary,
  departmentLeave,
  monthlyTrend,
  mostAbsent,
  exportReport,
} = require('../controllers/reportController');

router.get('/summary', auth, authorize('Admin', 'HR'), summary);
router.get('/department-leave', auth, authorize('Admin', 'HR'), departmentLeave);
router.get('/monthly-trend', auth, authorize('Admin', 'HR'), monthlyTrend);
router.get('/most-absent', auth, authorize('Admin', 'HR'), mostAbsent);
router.get('/export/:type', auth, authorize('Admin', 'HR'), exportReport);

module.exports = router;
