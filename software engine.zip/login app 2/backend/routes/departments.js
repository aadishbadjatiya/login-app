const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const authorize = require('../middleware/authorize');
const { list, create, remove } = require('../controllers/departmentController');

router.get('/', auth, list);
router.post('/', auth, authorize('Admin'), create);
router.delete('/:id', auth, authorize('Admin'), remove);

module.exports = router;
