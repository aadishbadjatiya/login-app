const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const authorize = require('../middleware/authorize');
const { list, create, assign, returnAsset, history } = require('../controllers/assetController');

router.get('/', auth, list);
router.get('/:id/history', auth, history);
router.post('/', auth, authorize('Admin', 'HR'), create);
router.post('/:id/assign', auth, authorize('Admin', 'HR'), assign);
router.post('/:id/return', auth, authorize('Admin', 'HR'), returnAsset);

module.exports = router;
