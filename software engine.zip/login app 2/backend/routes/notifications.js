const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const { list, markRead, markAllRead } = require('../controllers/notificationController');

router.get('/', auth, list);
router.put('/:id/read', auth, markRead);
router.put('/read-all', auth, markAllRead);

module.exports = router;
