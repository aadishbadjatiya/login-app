const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const authorize = require('../middleware/authorize');
const { list } = require('../controllers/auditController');

router.get('/', auth, authorize('Admin', 'HR'), list);

module.exports = router;
