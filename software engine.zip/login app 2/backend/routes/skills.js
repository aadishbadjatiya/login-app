const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const authorize = require('../middleware/authorize');
const { list, create } = require('../controllers/skillController');

router.get('/', auth, list);
router.post('/', auth, authorize('Admin', 'HR'), create);

module.exports = router;
