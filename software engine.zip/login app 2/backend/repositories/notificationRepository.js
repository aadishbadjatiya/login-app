const db = require('../db');

const listNotifications = async userId => {
  const result = await db.query(
    `SELECT n.*, u.name AS sender_name
     FROM notifications n
     LEFT JOIN users u ON u.id = n.user_id
     WHERE n.user_id = $1
     ORDER BY n.created_at DESC`,
    [userId]
  );
  return result.rows;
};

const createNotification = async ({ user_id, title, message }) => {
  const result = await db.query(
    `INSERT INTO notifications (user_id, title, message, is_read, created_at)
     VALUES ($1, $2, $3, false, NOW())
     RETURNING *`,
    [user_id, title, message]
  );
  return result.rows[0];
};

const markRead = async (notificationId, userId) => {
  const result = await db.query(
    `UPDATE notifications SET is_read = true WHERE id = $1 AND user_id = $2 RETURNING *`,
    [notificationId, userId]
  );
  return result.rows[0];
};

const markAllRead = async userId => {
  await db.query('UPDATE notifications SET is_read = true WHERE user_id = $1', [userId]);
};

module.exports = { listNotifications, createNotification, markRead, markAllRead };
