const db = require('../db');

const listAssets = async () => {
  const result = await db.query(
    `SELECT a.*, 
      p.user_id AS employee_user_id,
      u.name AS employee_name,
      al.allocated_date,
      al.return_date,
      al.status AS allocation_status
    FROM assets a
    LEFT JOIN LATERAL (
      SELECT * FROM asset_allocations aa
      WHERE aa.asset_id = a.id
      ORDER BY aa.allocated_date DESC
      LIMIT 1
    ) al ON true
    LEFT JOIN employee_profiles p ON p.id = al.employee_id
    LEFT JOIN users u ON u.id = p.user_id
    ORDER BY a.asset_name`
  );
  return result.rows;
};

const getAssetById = async assetId => {
  const result = await db.query('SELECT * FROM assets WHERE id = $1', [assetId]);
  return result.rows[0];
};

const createAsset = async asset => {
  const result = await db.query(
    `INSERT INTO assets (asset_code, asset_name, asset_type, purchase_date, purchase_cost, status)
     VALUES ($1, $2, $3, $4, $5, $6)
     RETURNING *`,
    [asset.asset_code, asset.asset_name, asset.asset_type, asset.purchase_date, asset.purchase_cost, asset.status]
  );
  return result.rows[0];
};

const addAssetHistory = async ({ asset_id, action, remarks, created_by }) => {
  await db.query(
    `INSERT INTO asset_history (asset_id, action, remarks, created_by, created_at)
     VALUES ($1, $2, $3, $4, NOW())`,
    [asset_id, action, remarks, created_by]
  );
};

const listAssetHistory = async assetId => {
  const result = await db.query(
    `SELECT ah.*, u.name AS performed_by_name
     FROM asset_history ah
     LEFT JOIN users u ON u.id = ah.created_by
     WHERE ah.asset_id = $1
     ORDER BY ah.created_at DESC`,
    [assetId]
  );
  return result.rows;
};

const createAllocation = async ({ asset_id, employee_id, allocated_by, return_date }) => {
  const result = await db.query(
    `INSERT INTO asset_allocations (asset_id, employee_id, allocated_by, allocated_date, return_date, status)
     VALUES ($1, $2, $3, CURRENT_DATE, $4, 'Allocated')
     RETURNING *`,
    [asset_id, employee_id, allocated_by, return_date]
  );
  return result.rows[0];
};

const updateAssetStatus = async (assetId, status) => {
  await db.query('UPDATE assets SET status = $1 WHERE id = $2', [status, assetId]);
};

const getActiveAllocation = async assetId => {
  const result = await db.query(
    `SELECT * FROM asset_allocations
     WHERE asset_id = $1 AND status = 'Allocated'
     ORDER BY allocated_date DESC
     LIMIT 1`,
    [assetId]
  );
  return result.rows[0];
};

const closeAllocation = async allocationId => {
  await db.query('UPDATE asset_allocations SET status = $1, return_date = CURRENT_DATE WHERE id = $2', ['Returned', allocationId]);
};

const countAssetMetrics = async () => {
  const result = await db.query(
    `SELECT
      COUNT(*) FILTER (WHERE status = 'Available') AS available_assets,
      COUNT(*) FILTER (WHERE status = 'Allocated') AS allocated_assets,
      COUNT(*) FILTER (WHERE status NOT IN ('Available', 'Allocated')) AS flagged_assets,
      COUNT(*) AS total_assets
    FROM assets`
  );
  return result.rows[0];
};

module.exports = {
  listAssets,
  getAssetById,
  createAsset,
  addAssetHistory,
  listAssetHistory,
  createAllocation,
  updateAssetStatus,
  getActiveAllocation,
  closeAllocation,
  countAssetMetrics,
};
