const notificationRepository = require('../repositories/notificationRepository');
const { recordAudit } = require('../utils/audit');

const listNotifications = userId => notificationRepository.listNotifications(userId);

const createNotification = async (notification, performed_by = null) => {
  const created = await notificationRepository.createNotification(notification);
  await recordAudit({
    table_name: 'notifications',
    action_type: 'CREATE',
    record_id: created.id,
    old_data: null,
    new_data: created,
    performed_by: performed_by || notification.user_id,
  });
  return created;
};

const markRead = async (notificationId, userId) => {
  const updated = await notificationRepository.markRead(notificationId, userId);
  if (updated) {
    await recordAudit({
      table_name: 'notifications',
      action_type: 'UPDATE',
      record_id: updated.id,
      old_data: { is_read: false },
      new_data: { is_read: true },
      performed_by: userId,
    });
  }
  return updated;
};

const markAllRead = async userId => {
  await notificationRepository.markAllRead(userId);
  await recordAudit({
    table_name: 'notifications',
    action_type: 'BULK_UPDATE',
    record_id: null,
    old_data: null,
    new_data: { is_read: true },
    performed_by: userId,
  });
};

module.exports = { listNotifications, createNotification, markRead, markAllRead };
