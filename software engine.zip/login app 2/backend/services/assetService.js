const db = require('../db');
const assetRepository = require('../repositories/assetRepository');
const notificationService = require('./notificationService');
const { recordAudit } = require('../utils/audit');

const listAssets = async () => assetRepository.listAssets();

const createAsset = async (assetData, actorId) => {
  const client = await db.getClient();
  try {
    await client.query('BEGIN');
    const insertResult = await client.query(
      `INSERT INTO assets (asset_code, asset_name, asset_type, purchase_date, purchase_cost, status)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [assetData.asset_code, assetData.asset_name, assetData.asset_type, assetData.purchase_date, assetData.purchase_cost, assetData.status]
    );
    const asset = insertResult.rows[0];
    await client.query(
      `INSERT INTO asset_history (asset_id, action, remarks, created_by, created_at)
       VALUES ($1, $2, $3, $4, NOW())`,
      [asset.id, 'Created', `Asset ${asset.asset_code} created`, actorId]
    );
    await recordAudit({
      table_name: 'assets',
      action_type: 'CREATE',
      record_id: asset.id,
      old_data: null,
      new_data: asset,
      performed_by: actorId,
    });
    await client.query('COMMIT');
    return asset;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
};

const assignAsset = async ({ asset_id, employee_id, allocated_by, return_date }, actorId) => {
  const client = await db.getClient();
  try {
    await client.query('BEGIN');
    const assetResult = await client.query('SELECT * FROM assets WHERE id = $1 FOR UPDATE', [asset_id]);
    const asset = assetResult.rows[0];
    if (!asset) throw new Error('Asset not found');
    if (asset.status === 'Allocated') throw new Error('Asset already assigned');

    await client.query('CALL assign_asset($1, $2, $3, $4)', [asset_id, employee_id, allocated_by, return_date]);
    const allocationResult = await client.query(
      `SELECT * FROM asset_allocations
       WHERE asset_id = $1 AND status = 'Allocated'
       ORDER BY allocated_date DESC
       LIMIT 1`,
      [asset_id]
    );
    const employeeResult = await client.query('SELECT user_id FROM employee_profiles WHERE id = $1', [employee_id]);
    const employeeUserId = employeeResult.rows[0]?.user_id;
    const allocation = allocationResult.rows[0];
    await client.query('COMMIT');

    if (employeeUserId) {
      await notificationService.createNotification({
        user_id: employeeUserId,
        title: 'Asset assigned',
        message: `Your asset ${asset.asset_name} has been assigned successfully`,
      }, actorId);
    }

    await recordAudit({
      table_name: 'asset_allocations',
      action_type: 'CREATE',
      record_id: allocation.id,
      old_data: null,
      new_data: allocation,
      performed_by: actorId,
    });
    return allocation;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
};

const returnAsset = async ({ asset_id, remarks }, actorId) => {
  const client = await db.getClient();
  try {
    await client.query('BEGIN');
    const allocationResult = await client.query(
      `SELECT * FROM asset_allocations
       WHERE asset_id = $1 AND status = 'Allocated'
       ORDER BY allocated_date DESC
       LIMIT 1`,
      [asset_id]
    );
    const allocation = allocationResult.rows[0];
    if (!allocation) throw new Error('No active allocation found for this asset');

    await client.query('CALL return_asset($1, $2, $3)', [asset_id, actorId, remarks]);
    await client.query(
      `INSERT INTO asset_history (asset_id, action, remarks, created_by, created_at)
       VALUES ($1, $2, $3, $4, NOW())`,
      [asset_id, 'Returned', remarks || 'Returned to inventory', actorId]
    );
    await client.query('COMMIT');

    await recordAudit({
      table_name: 'asset_allocations',
      action_type: 'UPDATE',
      record_id: allocation.id,
      old_data: allocation,
      new_data: { ...allocation, status: 'Returned' },
      performed_by: actorId,
    });
    return { message: 'Asset returned successfully' };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
};

const getAssetHistory = assetId => assetRepository.listAssetHistory(assetId);

const getAssetMetrics = () => assetRepository.countAssetMetrics();

module.exports = {
  listAssets,
  createAsset,
  assignAsset,
  returnAsset,
  getAssetHistory,
  getAssetMetrics,
};
