// Main Express Application Setup
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const path = require('path');
const rateLimit = require('express-rate-limit');
const swaggerUi = require('swagger-ui-express');

// Configuration and Utilities
const config = require('./src/config/environment');
const logger = require('./src/config/logger');
const { errorHandler, catchAsync } = require('./src/middleware/errorHandler');
const { pool, testConnection } = require('./src/config/database');
const { HTTP_CODES } = require('./src/constants');
const responseFormatter = require('./src/utils/response');

// Routes (to be updated with new versioned routes)
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/user');
const employeeRoutes = require('./routes/employees');
const departmentRoutes = require('./routes/departments');
const skillRoutes = require('./routes/skills');
const leaveRoutes = require('./routes/leaves');
const reportRoutes = require('./routes/reports');
const assetRoutes = require('./routes/assets');
const notificationRoutes = require('./routes/notifications');
const auditRoutes = require('./routes/audit');
const swaggerDocument = require('./swagger');

// Rate Limiters
const apiLimiter = rateLimit({
  windowMs: config.RATE_LIMIT.WINDOW_MS,
  max: config.RATE_LIMIT.MAX_REQUESTS,
  message: 'Too many requests from this IP, please try again later.',
  standardHeaders: true,
  legacyHeaders: false,
});

const authLimiter = rateLimit({
  windowMs: config.RATE_LIMIT.WINDOW_MS,
  max: config.RATE_LIMIT.AUTH_MAX_REQUESTS,
  message: 'Too many login attempts, please try again later.',
  skipSuccessfulRequests: true,
  standardHeaders: true,
  legacyHeaders: false,
});

// Initialize Express App
const app = express();

// ============== Middleware ==============
app.use(helmet());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));
app.use(cors({ origin: config.CLIENT_URL }));

// Serve uploaded files
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ============== Health Check ==============
app.get('/health', (req, res) => {
  res.status(HTTP_CODES.OK).json(
    responseFormatter.success({
      status: 'UP',
      uptime: process.uptime(),
      environment: config.NODE_ENV,
      timestamp: new Date().toISOString(),
    }, 'Server is healthy')
  );
});

// ============== API Documentation ==============
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument, {
  customCss: '.swagger-ui .topbar { display: none }',
}));

// ============== API Routes (Old Endpoints - Legacy Support) ==============
// TODO: Move these to src/routes with proper structure

// Auth Routes with Rate Limiting
app.use('/api/auth', authLimiter, authRoutes);

// Apply general API rate limiter
app.use('/api/', apiLimiter);

// Other Routes
app.use('/api/user', userRoutes);
app.use('/api/employees', employeeRoutes);
app.use('/api/departments', departmentRoutes);
app.use('/api/skills', skillRoutes);
app.use('/api/leaves', leaveRoutes);
app.use('/api/assets', assetRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/audit', auditRoutes);
app.use('/api/reports', reportRoutes);

// ============== 404 Handler ==============
app.use((req, res) => {
  res.status(HTTP_CODES.NOT_FOUND).json(
    responseFormatter.error('Resource not found', HTTP_CODES.NOT_FOUND)
  );
});

// ============== Error Handler ==============
app.use(errorHandler);

// ============== Database Connection Test ==============
const startServer = async () => {
  try {
    // Test database connection
    const dbConnected = await testConnection();
    if (!dbConnected) {
      logger.error('Failed to connect to database. Exiting...');
      process.exit(1);
    }

    // Start listening
    app.listen(config.PORT, () => {
      logger.info(`✅ WorkForce API Server Started`, {
        port: config.PORT,
        environment: config.NODE_ENV,
        url: `http://localhost:${config.PORT}`,
      });
    });
  } catch (error) {
    logger.fatal('Fatal error during server startup', {
      error: error.message,
      stack: error.stack,
    });
    process.exit(1);
  }
};

// ============== Graceful Shutdown ==============
process.on('SIGTERM', () => {
  logger.info('SIGTERM received, shutting down gracefully...');
  pool.end(() => {
    logger.info('Database pool closed');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  logger.info('SIGINT received, shutting down gracefully...');
  pool.end(() => {
    logger.info('Database pool closed');
    process.exit(0);
  });
});

process.on('unhandledRejection', (reason, promise) => {
  logger.fatal('Unhandled Rejection', {
    reason,
    promise: promise.toString(),
  });
});

process.on('uncaughtException', (error) => {
  logger.fatal('Uncaught Exception', {
    error: error.message,
    stack: error.stack,
  });
  process.exit(1);
});

// Start the server
startServer();

module.exports = app;
