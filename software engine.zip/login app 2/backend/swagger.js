module.exports = {
  openapi: '3.0.0',
  info: {
    title: 'WorkForce HR API',
    version: '1.0.0',
    description: 'WorkForce HR Management System API documentation',
  },
  servers: [{ url: '/' }],
  paths: {
    '/api/auth/signup': { post: { summary: 'Sign up user' } },
    '/api/auth/login': { post: { summary: 'Login user' } },
    '/api/auth/refresh-token': { post: { summary: 'Refresh token' } },
    '/api/auth/logout': { post: { summary: 'Logout user' } },
    '/api/user/profile': { get: { summary: 'Get current user profile' } },
    '/api/employees': { get: { summary: 'List employees' }, post: { summary: 'Create employee' } },
    '/api/departments': { get: { summary: 'List departments' } },
    '/api/skills': { get: { summary: 'List skills' } },
    '/api/leaves': { get: { summary: 'List leaves' } },
    '/api/reports/summary': { get: { summary: 'Get summary report' } },
  },
};
