CREATE TYPE IF NOT EXISTS user_role AS ENUM ('Admin', 'HR', 'Manager', 'Employee');

CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  role user_role NOT NULL,
  verified BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS refresh_tokens (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  token TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS password_resets (
  id SERIAL PRIMARY KEY,
  user_id INTEGER UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  token TEXT NOT NULL,
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL
);

CREATE TABLE IF NOT EXISTS departments (
  id SERIAL PRIMARY KEY,
  department_name TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS skills (
  id SERIAL PRIMARY KEY,
  skill_name TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS employee_profiles (
  id SERIAL PRIMARY KEY,
  user_id INTEGER UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  department_id INTEGER REFERENCES departments(id),
  phone TEXT,
  address TEXT,
  designation TEXT,
  salary NUMERIC(12,2),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS employee_images (
  id SERIAL PRIMARY KEY,
  employee_id INTEGER REFERENCES employee_profiles(id) ON DELETE CASCADE,
  image_url TEXT NOT NULL,
  label TEXT
);

CREATE TABLE IF NOT EXISTS employee_skills (
  id SERIAL PRIMARY KEY,
  employee_id INTEGER REFERENCES employee_profiles(id) ON DELETE CASCADE,
  skill_id INTEGER REFERENCES skills(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS leave_types (
  id SERIAL PRIMARY KEY,
  leave_name TEXT NOT NULL UNIQUE,
  total_days INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS leave_balance (
  id SERIAL PRIMARY KEY,
  employee_id INTEGER REFERENCES employee_profiles(id) ON DELETE CASCADE,
  leave_type_id INTEGER REFERENCES leave_types(id) ON DELETE CASCADE,
  available_days INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS leave_applications (
  id SERIAL PRIMARY KEY,
  employee_id INTEGER REFERENCES employee_profiles(id) ON DELETE CASCADE,
  leave_type_id INTEGER REFERENCES leave_types(id),
  from_date DATE NOT NULL,
  to_date DATE NOT NULL,
  total_days INTEGER NOT NULL,
  reason TEXT,
  status TEXT NOT NULL DEFAULT 'Pending',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS approval_history (
  id SERIAL PRIMARY KEY,
  leave_id INTEGER REFERENCES leave_applications(id) ON DELETE CASCADE,
  approved_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  remarks TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE VIEW IF NOT EXISTS v_employees AS
SELECT u.id AS user_id,
       u.name,
       u.email,
       u.role,
       p.id AS profile_id,
       p.department_id,
       d.department_name,
       p.phone,
       p.address,
       p.designation,
       p.salary,
       p.created_at
FROM users u
JOIN employee_profiles p ON p.user_id = u.id
LEFT JOIN departments d ON d.id = p.department_id;

CREATE VIEW IF NOT EXISTS v_leave_summary AS
SELECT la.id AS leave_id,
       u.name AS employee_name,
       d.department_name,
       lt.leave_name,
       la.from_date,
       la.to_date,
       la.total_days,
       la.reason,
       la.status,
       la.created_at
FROM leave_applications la
JOIN employee_profiles p ON p.id = la.employee_id
JOIN users u ON u.id = p.user_id
LEFT JOIN departments d ON d.id = p.department_id
LEFT JOIN leave_types lt ON lt.id = la.leave_type_id;

CREATE OR REPLACE FUNCTION approve_leave(leave_id INTEGER, approver_id INTEGER, action TEXT, remarks TEXT)
RETURNS VOID AS $$
DECLARE
  application RECORD;
  balance RECORD;
BEGIN
  SELECT * INTO application FROM leave_applications WHERE id = leave_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Leave application not found';
  END IF;

  IF application.status <> 'Pending' THEN
    RAISE EXCEPTION 'Leave application already processed';
  END IF;

  IF action = 'Approved' THEN
    SELECT * INTO balance FROM leave_balance
      WHERE employee_id = application.employee_id AND leave_type_id = application.leave_type_id FOR UPDATE;
    IF NOT FOUND THEN
      RAISE EXCEPTION 'Leave balance not found';
    END IF;
    IF balance.available_days < application.total_days THEN
      RAISE EXCEPTION 'Insufficient leave balance';
    END IF;
    UPDATE leave_balance
      SET available_days = available_days - application.total_days
      WHERE id = balance.id;
    UPDATE leave_applications SET status = 'Approved' WHERE id = leave_id;
  ELSE
    UPDATE leave_applications SET status = 'Rejected' WHERE id = leave_id;
  END IF;

  INSERT INTO approval_history (leave_id, approved_by, action, remarks, created_at)
  VALUES (leave_id, approver_id, action, remarks, NOW());
END;
$$ LANGUAGE plpgsql;

INSERT INTO departments (department_name)
VALUES ('IT'), ('HR'), ('Finance'), ('Marketing'), ('Operations')
ON CONFLICT (department_name) DO NOTHING;

INSERT INTO skills (skill_name)
VALUES ('React'), ('Node.js'), ('PostgreSQL'), ('Python'), ('Java'), ('AWS'), ('Docker'), ('Figma')
ON CONFLICT (skill_name) DO NOTHING;

INSERT INTO leave_types (leave_name, total_days)
VALUES ('Casual', 12), ('Sick', 10), ('Earned', 15), ('Maternity', 90)
ON CONFLICT (leave_name) DO NOTHING;

CREATE TABLE IF NOT EXISTS assets (
  id SERIAL PRIMARY KEY,
  asset_code VARCHAR(50) UNIQUE NOT NULL,
  asset_name VARCHAR(200) NOT NULL,
  asset_type VARCHAR(100) NOT NULL,
  purchase_date DATE NOT NULL,
  purchase_cost NUMERIC(12,2) NOT NULL,
  status VARCHAR(50) NOT NULL DEFAULT 'Available'
);

CREATE TABLE IF NOT EXISTS asset_allocations (
  id SERIAL PRIMARY KEY,
  asset_id INT REFERENCES assets(id) ON DELETE CASCADE,
  employee_id INT REFERENCES employee_profiles(id) ON DELETE SET NULL,
  allocated_by INT REFERENCES users(id) ON DELETE SET NULL,
  allocated_date DATE NOT NULL DEFAULT CURRENT_DATE,
  return_date DATE,
  status VARCHAR(50) NOT NULL DEFAULT 'Allocated'
);

CREATE TABLE IF NOT EXISTS asset_history (
  id SERIAL PRIMARY KEY,
  asset_id INT REFERENCES assets(id) ON DELETE CASCADE,
  action VARCHAR(100) NOT NULL,
  remarks TEXT,
  created_by INT REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS notifications (
  id SERIAL PRIMARY KEY,
  user_id INT REFERENCES users(id) ON DELETE CASCADE,
  title VARCHAR(200) NOT NULL,
  message TEXT NOT NULL,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id SERIAL PRIMARY KEY,
  table_name VARCHAR(100) NOT NULL,
  action_type VARCHAR(50) NOT NULL,
  record_id INT,
  old_data JSONB,
  new_data JSONB,
  performed_by INT REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE VIEW IF NOT EXISTS employee_summary AS
SELECT
  u.name,
  d.department_name,
  ep.designation
FROM users u
JOIN employee_profiles ep ON u.id = ep.user_id
JOIN departments d ON d.id = ep.department_id;

CREATE VIEW IF NOT EXISTS asset_summary AS
SELECT
  a.id AS asset_id,
  a.asset_code,
  a.asset_name,
  a.asset_type,
  a.purchase_date,
  a.purchase_cost,
  a.status AS asset_status,
  al.status AS allocation_status,
  al.allocated_date,
  al.return_date,
  p.user_id AS employee_user_id,
  u.name AS employee_name
FROM assets a
LEFT JOIN LATERAL (
  SELECT * FROM asset_allocations aa
  WHERE aa.asset_id = a.id
  ORDER BY aa.allocated_date DESC
  LIMIT 1
) al ON true
LEFT JOIN employee_profiles p ON p.id = al.employee_id
LEFT JOIN users u ON u.id = p.user_id;

CREATE OR REPLACE FUNCTION calculate_leave_balance(employee INTEGER)
RETURNS TABLE(leave_name TEXT, available_days INTEGER) AS $$
BEGIN
  RETURN QUERY
  SELECT lt.leave_name, lb.available_days
  FROM leave_balance lb
  JOIN leave_types lt ON lt.id = lb.leave_type_id
  WHERE lb.employee_id = employee;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION assign_asset(p_asset_id INTEGER, p_employee_id INTEGER, p_allocated_by INTEGER, p_return_date DATE)
RETURNS VOID AS $$
DECLARE
  existing_asset RECORD;
BEGIN
  SELECT * INTO existing_asset FROM assets WHERE id = p_asset_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Asset not found';
  END IF;
  IF existing_asset.status = 'Allocated' THEN
    RAISE EXCEPTION 'Asset already allocated';
  END IF;

  INSERT INTO asset_allocations (asset_id, employee_id, allocated_by, allocated_date, return_date, status)
  VALUES (p_asset_id, p_employee_id, p_allocated_by, CURRENT_DATE, p_return_date, 'Allocated');

  UPDATE assets SET status = 'Allocated' WHERE id = p_asset_id;

  INSERT INTO asset_history (asset_id, action, remarks, created_by, created_at)
  VALUES (p_asset_id, 'Assigned', CONCAT('Assigned to employee ', p_employee_id::text), p_allocated_by, NOW());
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION return_asset(p_asset_id INTEGER, p_performed_by INTEGER, p_remarks TEXT)
RETURNS VOID AS $$
DECLARE
  current_alloc RECORD;
BEGIN
  SELECT * INTO current_alloc
  FROM asset_allocations
  WHERE asset_id = p_asset_id
    AND status = 'Allocated'
  ORDER BY allocated_date DESC
  LIMIT 1
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'No active allocation found for asset';
  END IF;

  UPDATE asset_allocations
  SET status = 'Returned', return_date = CURRENT_DATE
  WHERE id = current_alloc.id;

  UPDATE assets SET status = 'Available' WHERE id = p_asset_id;

  INSERT INTO asset_history (asset_id, action, remarks, created_by, created_at)
  VALUES (p_asset_id, 'Returned', COALESCE(p_remarks, 'Asset returned'), p_performed_by, NOW());
END;
$$ LANGUAGE plpgsql;
