const db = require('../db');

const recordAudit = async ({ table_name, action_type, record_id, old_data = null, new_data = null, performed_by }) => {
  await db.query(
    `INSERT INTO audit_logs (table_name, action_type, record_id, old_data, new_data, performed_by, created_at)
     VALUES ($1, $2, $3, $4, $5, $6, NOW())`,
    [table_name, action_type, record_id, old_data, new_data, performed_by]
  );
};

module.exports = { recordAudit };
