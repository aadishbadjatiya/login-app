const db = require('../db');
const assetService = require('../services/assetService');

const summary = async (req, res, next) => {
  try {
    const totalEmployees = await db.query('SELECT COUNT(*) FROM employee_profiles');
    const totalDepartments = await db.query('SELECT COUNT(*) FROM departments');
    const totalLeaves = await db.query('SELECT COUNT(*) FROM leave_applications');
    const pendingLeaves = await db.query("SELECT COUNT(*) FROM leave_applications WHERE status = 'Pending'");
    const assetMetrics = await assetService.getAssetMetrics();
    res.json({
      totalEmployees: Number(totalEmployees.rows[0].count),
      totalDepartments: Number(totalDepartments.rows[0].count),
      totalLeaves: Number(totalLeaves.rows[0].count),
      pendingLeaves: Number(pendingLeaves.rows[0].count),
      totalAssets: Number(assetMetrics.total_assets),
      allocatedAssets: Number(assetMetrics.allocated_assets),
      availableAssets: Number(assetMetrics.available_assets),
    });
  } catch (err) {
    next(err);
  }
};

const exportReport = async (req, res, next) => {
  try {
    const { type } = req.params;
    let result;

    if (type === 'employees') {
      result = await db.query(
        `SELECT u.name AS employee_name,
                u.email,
                d.department_name,
                p.designation,
                p.salary,
                p.phone,
                p.address
         FROM users u
         JOIN employee_profiles p ON p.user_id = u.id
         LEFT JOIN departments d ON d.id = p.department_id
         ORDER BY u.name`
      );
    } else if (type === 'leaves') {
      result = await db.query(
        `SELECT u.name AS employee_name,
                d.department_name,
                lt.leave_name,
                la.from_date,
                la.to_date,
                la.total_days,
                la.reason,
                la.status,
                la.created_at
         FROM leave_applications la
         JOIN employee_profiles p ON p.id = la.employee_id
         JOIN users u ON u.id = p.user_id
         LEFT JOIN departments d ON d.id = p.department_id
         LEFT JOIN leave_types lt ON lt.id = la.leave_type_id
         ORDER BY la.created_at DESC`
      );
    } else if (type === 'assets') {
      result = await db.query(
        `SELECT a.asset_code,
                a.asset_name,
                a.asset_type,
                a.purchase_date,
                a.purchase_cost,
                a.status AS asset_status,
                u.name AS allocated_to,
                al.allocated_date,
                al.return_date
         FROM assets a
         LEFT JOIN LATERAL (
           SELECT * FROM asset_allocations aa
           WHERE aa.asset_id = a.id
           ORDER BY aa.allocated_date DESC
           LIMIT 1
         ) al ON true
         LEFT JOIN employee_profiles p ON p.id = al.employee_id
         LEFT JOIN users u ON u.id = p.user_id
         ORDER BY a.asset_name`
      );
    } else {
      return res.status(400).json({ error: 'Unsupported export type' });
    }

    res.json(result.rows);
  } catch (err) {
    next(err);
  }
};

const departmentLeave = async (req, res, next) => {
  try {
    const result = await db.query(
      `SELECT d.department_name,
        SUM(CASE WHEN la.status = 'Approved' THEN 1 ELSE 0 END) AS approved,
        SUM(CASE WHEN la.status = 'Pending' THEN 1 ELSE 0 END) AS pending,
        SUM(CASE WHEN la.status = 'Rejected' THEN 1 ELSE 0 END) AS rejected
      FROM leave_applications la
      JOIN employee_profiles p ON p.id = la.employee_id
      JOIN departments d ON d.id = p.department_id
      GROUP BY d.department_name
      ORDER BY d.department_name`
    );
    res.json(result.rows);
  } catch (err) {
    next(err);
  }
};

const monthlyTrend = async (req, res, next) => {
  try {
    const result = await db.query(
      `SELECT TO_CHAR(created_at, 'YYYY-MM') AS month,
        SUM(total_days) AS total_days
      FROM leave_applications
      GROUP BY month
      ORDER BY month`
    );
    res.json(result.rows);
  } catch (err) {
    next(err);
  }
};

const mostAbsent = async (req, res, next) => {
  try {
    const result = await db.query(
      `SELECT u.name, d.department_name, SUM(la.total_days) AS absent_days
      FROM leave_applications la
      JOIN employee_profiles p ON p.id = la.employee_id
      JOIN users u ON u.id = p.user_id
      LEFT JOIN departments d ON d.id = p.department_id
      WHERE la.status = 'Approved'
      GROUP BY u.name, d.department_name
      ORDER BY absent_days DESC
      LIMIT 1`
    );
    res.json(result.rows[0] || { name: null, department_name: null, absent_days: 0 });
  } catch (err) {
    next(err);
  }
};

module.exports = { summary, departmentLeave, monthlyTrend, mostAbsent };
