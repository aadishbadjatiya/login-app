const db = require('../db');
const { leaveRequestSchema } = require('../utils/validators');
const notificationService = require('../services/notificationService');
const { recordAudit } = require('../utils/audit');

const list = async (req, res, next) => {
  try {
    const { status, employee_id } = req.query;
    const clauses = [];
    const values = [];
    if (status) {
      values.push(status);
      clauses.push(`la.status = $${values.length}`);
    }
    if (employee_id) {
      values.push(employee_id);
      clauses.push(`la.employee_id = $${values.length}`);
    }
    const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
    const result = await db.query(
      `SELECT la.*, lt.leave_name, lt.total_days AS max_days,
        u.name AS employee_name,
        d.department_name
      FROM leave_applications la
      JOIN leave_types lt ON lt.id = la.leave_type_id
      JOIN employee_profiles p ON p.id = la.employee_id
      JOIN users u ON u.id = p.user_id
      LEFT JOIN departments d ON d.id = p.department_id
      ${where}
      ORDER BY la.created_at DESC`,
      values
    );
    res.json(result.rows);
  } catch (err) {
    next(err);
  }
};

const types = async (req, res, next) => {
  try {
    const result = await db.query('SELECT id, leave_name, total_days FROM leave_types ORDER BY id');
    res.json(result.rows);
  } catch (err) {
    next(err);
  }
};

const balance = async (req, res, next) => {
  try {
    const { employee_id } = req.params;
    const result = await db.query(
      `SELECT lb.id, lt.leave_name, lb.available_days
      FROM leave_balance lb
      JOIN leave_types lt ON lt.id = lb.leave_type_id
      WHERE lb.employee_id = $1`,
      [employee_id]
    );
    res.json(result.rows);
  } catch (err) {
    next(err);
  }
};

const apply = async (req, res, next) => {
  const client = await db.getClient();
  try {
    const { error, value } = leaveRequestSchema.validate(req.body);
    if (error) return res.status(400).json({ error: error.details[0].message });

    const fromDate = new Date(value.from_date);
    const toDate = new Date(value.to_date);
    if (toDate < fromDate) return res.status(400).json({ error: 'to_date must be after from_date' });

    const totalDays = Math.max(1, Math.round((toDate - fromDate) / (1000 * 60 * 60 * 24)) + 1);
    const balanceResult = await client.query(
      'SELECT available_days FROM leave_balance WHERE employee_id = $1 AND leave_type_id = $2',
      [value.employee_id, value.leave_type_id]
    );
    const balanceRow = balanceResult.rows[0];
    if (!balanceRow) return res.status(400).json({ error: 'Leave balance record not found' });
    if (balanceRow.available_days < totalDays) return res.status(400).json({ error: 'Insufficient leave balance' });

    await client.query('BEGIN');
    const insertResult = await client.query(
      `INSERT INTO leave_applications (employee_id, leave_type_id, from_date, to_date, total_days, reason, status, created_at)
      VALUES ($1, $2, $3, $4, $5, $6, 'Pending', NOW()) RETURNING *`,
      [value.employee_id, value.leave_type_id, value.from_date, value.to_date, totalDays, value.reason]
    );
    const application = insertResult.rows[0];
    await recordAudit({
      table_name: 'leave_applications',
      action_type: 'CREATE',
      record_id: application.id,
      old_data: null,
      new_data: application,
      performed_by: req.user.id,
    });
    await client.query('COMMIT');
    res.status(201).json({ message: 'Leave application submitted', leave_id: application.id });
  } catch (err) {
    await client.query('ROLLBACK');
    next(err);
  } finally {
    client.release();
  }
};

const approve = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { action, remarks } = req.body;
    if (!['Approved', 'Rejected'].includes(action)) {
      return res.status(400).json({ error: 'Action must be Approved or Rejected' });
    }
    const beforeResult = await db.query('SELECT * FROM leave_applications WHERE id = $1', [id]);
    const before = beforeResult.rows[0];
    if (!before) return res.status(404).json({ error: 'Leave application not found' });

    await db.query('CALL approve_leave($1, $2, $3, $4)', [id, req.user.id, action, remarks || '']);

    const afterResult = await db.query('SELECT * FROM leave_applications WHERE id = $1', [id]);
    const after = afterResult.rows[0];
    await recordAudit({
      table_name: 'leave_applications',
      action_type: 'UPDATE',
      record_id: Number(id),
      old_data: before,
      new_data: after,
      performed_by: req.user.id,
    });

    const employeeResult = await db.query(
      `SELECT p.user_id FROM leave_applications la
       JOIN employee_profiles p ON p.id = la.employee_id
       WHERE la.id = $1`,
      [id]
    );
    const employeeUserId = employeeResult.rows[0]?.user_id;
    if (employeeUserId) {
      await notificationService.createNotification({
        user_id: employeeUserId,
        title: 'Leave application update',
        message: `Your leave request has been ${action.toLowerCase()}`,
      }, req.user.id);
    }

    res.json({ message: `Leave ${action.toLowerCase()} successfully` });
  } catch (err) {
    next(err);
  }
};

const history = async (req, res, next) => {
  try {
    const { id } = req.params;
    const result = await db.query(
      `SELECT ah.id, ah.action, ah.remarks, ah.created_at,
        u.name AS approved_by_name
      FROM approval_history ah
      LEFT JOIN users u ON u.id = ah.approved_by
      WHERE ah.leave_id = $1
      ORDER BY ah.created_at DESC`,
      [id]
    );
    res.json(result.rows);
  } catch (err) {
    next(err);
  }
};

module.exports = { list, types, balance, apply, approve, history };
