const assetService = require('../services/assetService');
const { assetSchema, assetAssignSchema, assetReturnSchema } = require('../utils/validators');

const list = async (req, res, next) => {
  try {
    const assets = await assetService.listAssets();
    res.json(assets);
  } catch (err) {
    next(err);
  }
};

const create = async (req, res, next) => {
  try {
    const { error, value } = assetSchema.validate(req.body);
    if (error) return res.status(400).json({ error: error.details[0].message });
    const asset = await assetService.createAsset(value, req.user.id);
    res.status(201).json(asset);
  } catch (err) {
    next(err);
  }
};

const assign = async (req, res, next) => {
  try {
    const { error, value } = assetAssignSchema.validate({ asset_id: Number(req.params.id), ...req.body });
    if (error) return res.status(400).json({ error: error.details[0].message });
    const allocation = await assetService.assignAsset(value, req.user.id);
    res.status(201).json(allocation);
  } catch (err) {
    next(err);
  }
};

const returnAsset = async (req, res, next) => {
  try {
    const payload = { asset_id: Number(req.params.id), ...req.body };
    const { error, value } = assetReturnSchema.validate(payload);
    if (error) return res.status(400).json({ error: error.details[0].message });
    const result = await assetService.returnAsset(value, req.user.id);
    res.json(result);
  } catch (err) {
    next(err);
  }
};

const history = async (req, res, next) => {
  try {
    const assetId = Number(req.params.id);
    const history = await assetService.getAssetHistory(assetId);
    res.json(history);
  } catch (err) {
    next(err);
  }
};

module.exports = { list, create, assign, returnAsset, history };
