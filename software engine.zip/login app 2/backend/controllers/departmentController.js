const db = require('../db');

const list = async (req, res, next) => {
  try {
    const result = await db.query('SELECT id, department_name FROM departments ORDER BY department_name');
    res.json(result.rows);
  } catch (err) {
    next(err);
  }
};

const create = async (req, res, next) => {
  try {
    const { department_name } = req.body;
    if (!department_name) return res.status(400).json({ error: 'department_name is required' });
    const result = await db.query('INSERT INTO departments (department_name) VALUES ($1) RETURNING id, department_name', [department_name]);
    res.status(201).json(result.rows[0]);
  } catch (err) {
    next(err);
  }
};

const remove = async (req, res, next) => {
  try {
    const { id } = req.params;
    await db.query('DELETE FROM departments WHERE id = $1', [id]);
    res.json({ message: 'Department deleted' });
  } catch (err) {
    next(err);
  }
};

module.exports = { list, create, remove };
