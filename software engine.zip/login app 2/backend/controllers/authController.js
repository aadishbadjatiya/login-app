const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const dotenv = require('dotenv');
const db = require('../db');
const {
  signupSchema,
  loginSchema,
  passwordResetSchema,
  resetPasswordSchema,
} = require('../utils/validators');

dotenv.config();

const signToken = (user, secret, expiresIn) =>
  jwt.sign({ id: user.id, name: user.name, email: user.email, role: user.role }, secret, {
    expiresIn,
  });

const signup = async (req, res, next) => {
  try {
    const { error, value } = signupSchema.validate(req.body);
    if (error) return res.status(400).json({ error: error.details[0].message });

    const existing = await db.query('SELECT id FROM users WHERE email = $1', [value.email]);
    if (existing.rows.length) return res.status(409).json({ error: 'Email already exists' });

    const hashed = await bcrypt.hash(value.password, 12);
    const result = await db.query(
      'INSERT INTO users (name, email, password, role, verified, created_at) VALUES ($1, $2, $3, $4, true, NOW()) RETURNING id, name, email, role, verified, created_at',
      [value.name, value.email, hashed, value.role]
    );

    res.status(201).json(result.rows[0]);
  } catch (err) {
    next(err);
  }
};

const login = async (req, res, next) => {
  try {
    const { error, value } = loginSchema.validate(req.body);
    if (error) return res.status(400).json({ error: error.details[0].message });

    const result = await db.query('SELECT * FROM users WHERE email = $1', [value.email]);
    const user = result.rows[0];
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });

    const isValid = await bcrypt.compare(value.password, user.password);
    if (!isValid) return res.status(401).json({ error: 'Invalid credentials' });

    const accessToken = signToken(user, process.env.JWT_SECRET, '15m');
    const refreshToken = signToken(user, process.env.REFRESH_SECRET, '30d');

    await db.query('INSERT INTO refresh_tokens (user_id, token, created_at) VALUES ($1, $2, NOW())', [user.id, refreshToken]);

    res.json({
      accessToken,
      refreshToken,
      user: { id: user.id, name: user.name, email: user.email, role: user.role, verified: user.verified },
    });
  } catch (err) {
    next(err);
  }
};

const refreshToken = async (req, res, next) => {
  try {
    const { token } = req.body;
    if (!token) return res.status(400).json({ error: 'Refresh token required' });

    const stored = await db.query('SELECT * FROM refresh_tokens WHERE token = $1', [token]);
    if (!stored.rows.length) return res.status(401).json({ error: 'Invalid refresh token' });

    const payload = jwt.verify(token, process.env.REFRESH_SECRET);
    const userResult = await db.query('SELECT id, name, email, role, verified FROM users WHERE id = $1', [payload.id]);
    const user = userResult.rows[0];
    if (!user) return res.status(401).json({ error: 'User not found' });

    const accessToken = signToken(user, process.env.JWT_SECRET, '15m');
    const newRefreshToken = signToken(user, process.env.REFRESH_SECRET, '30d');

    await db.query('UPDATE refresh_tokens SET token = $1, created_at = NOW() WHERE token = $2', [newRefreshToken, token]);
    res.json({ accessToken, refreshToken: newRefreshToken });
  } catch (err) {
    if (err.name === 'TokenExpiredError' || err.name === 'JsonWebTokenError') {
      return res.status(401).json({ error: 'Refresh token invalid or expired' });
    }
    next(err);
  }
};

const logout = async (req, res, next) => {
  try {
    const { token } = req.body;
    if (!token) return res.status(400).json({ error: 'Refresh token required' });
    await db.query('DELETE FROM refresh_tokens WHERE token = $1', [token]);
    res.json({ message: 'Logged out successfully' });
  } catch (err) {
    next(err);
  }
};

const forgotPassword = async (req, res, next) => {
  try {
    const { error, value } = passwordResetSchema.validate(req.body);
    if (error) return res.status(400).json({ error: error.details[0].message });

    const userResult = await db.query('SELECT id FROM users WHERE email = $1', [value.email]);
    const user = userResult.rows[0];
    if (!user) return res.status(404).json({ error: 'User not found' });

    const resetToken = crypto.randomBytes(24).toString('hex');
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000);

    await db.query(
      'INSERT INTO password_resets (user_id, token, expires_at) VALUES ($1, $2, $3) ON CONFLICT (user_id) DO UPDATE SET token = EXCLUDED.token, expires_at = EXCLUDED.expires_at',
      [user.id, resetToken, expiresAt]
    );

    res.json({ message: 'Password reset token generated', resetToken });
  } catch (err) {
    next(err);
  }
};

const resetPassword = async (req, res, next) => {
  try {
    const { error, value } = resetPasswordSchema.validate(req.body);
    if (error) return res.status(400).json({ error: error.details[0].message });

    const tokenResult = await db.query(
      'SELECT user_id, expires_at FROM password_resets WHERE token = $1',
      [value.token]
    );
    const reset = tokenResult.rows[0];
    if (!reset || new Date(reset.expires_at) < new Date()) {
      return res.status(400).json({ error: 'Reset token invalid or expired' });
    }

    const hashed = await bcrypt.hash(value.password, 12);
    await db.query('UPDATE users SET password = $1 WHERE id = $2', [hashed, reset.user_id]);
    await db.query('DELETE FROM password_resets WHERE user_id = $1', [reset.user_id]);

    res.json({ message: 'Password reset successfully' });
  } catch (err) {
    next(err);
  }
};

module.exports = { signup, login, refreshToken, logout, forgotPassword, resetPassword };
