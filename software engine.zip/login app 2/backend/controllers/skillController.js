const db = require('../db');

const list = async (req, res, next) => {
  try {
    const result = await db.query('SELECT id, skill_name FROM skills ORDER BY skill_name');
    res.json(result.rows);
  } catch (err) {
    next(err);
  }
};

const create = async (req, res, next) => {
  try {
    const { skill_name } = req.body;
    if (!skill_name) return res.status(400).json({ error: 'skill_name is required' });
    const inserted = await db.query('INSERT INTO skills (skill_name) VALUES ($1) RETURNING id, skill_name', [skill_name]);
    res.status(201).json(inserted.rows[0]);
  } catch (err) {
    next(err);
  }
};

module.exports = { list, create };
