const db = require('../db');

const list = async (req, res, next) => {
  try {
    const { table_name, action_type, per_page = 50, page = 1 } = req.query;
    const clauses = [];
    const values = [];

    if (table_name) {
      values.push(table_name);
      clauses.push(`table_name = $${values.length}`);
    }
    if (action_type) {
      values.push(action_type);
      clauses.push(`action_type = $${values.length}`);
    }

    const whereClause = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
    const limit = Number(per_page) > 0 ? Number(per_page) : 50;
    const offset = (Number(page) - 1) * limit;

    const result = await db.query(
      `SELECT * FROM audit_logs ${whereClause} ORDER BY created_at DESC LIMIT $${values.length + 1} OFFSET $${values.length + 2}`,
      [...values, limit, offset]
    );
    res.json(result.rows);
  } catch (err) {
    next(err);
  }
};

module.exports = { list };
