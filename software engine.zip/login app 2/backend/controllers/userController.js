const db = require('../db');

const profile = async (req, res, next) => {
  try {
    const result = await db.query('SELECT id, name, email, role, verified, created_at FROM users WHERE id = $1', [req.user.id]);
    if (!result.rows.length) return res.status(404).json({ error: 'User not found' });
    res.json(result.rows[0]);
  } catch (err) {
    next(err);
  }
};

module.exports = { profile };
