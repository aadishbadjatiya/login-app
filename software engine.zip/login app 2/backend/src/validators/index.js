// Joi Validators for all entities
const Joi = require('joi');

// Email regex pattern
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const phonePattern = /^[0-9]{10,}$/;

// Common schemas
const commonSchemas = {
  email: Joi.string().email().required().messages({
    'string.email': 'Please provide a valid email address',
    'any.required': 'Email is required',
  }),
  password: Joi.string().min(8).required().messages({
    'string.min': 'Password must be at least 8 characters long',
    'any.required': 'Password is required',
  }),
  phone: Joi.string().pattern(phonePattern).optional().messages({
    'string.pattern.base': 'Please provide a valid phone number',
  }),
  date: Joi.date().iso().required(),
  pagination: {
    page: Joi.number().integer().min(1).default(1),
    limit: Joi.number().integer().min(1).max(100).default(10),
  },
};

// Auth Validators
const authValidators = {
  login: Joi.object({
    email: commonSchemas.email,
    password: Joi.string().required(),
  }),

  register: Joi.object({
    email: commonSchemas.email,
    password: commonSchemas.password,
    fullName: Joi.string().min(2).required(),
  }),

  refreshToken: Joi.object({
    refreshToken: Joi.string().required(),
  }),

  changePassword: Joi.object({
    currentPassword: Joi.string().required(),
    newPassword: commonSchemas.password,
    confirmPassword: Joi.string().valid(Joi.ref('newPassword')).required().messages({
      'any.only': 'Passwords do not match',
    }),
  }),

  forgotPassword: Joi.object({
    email: commonSchemas.email,
  }),

  resetPassword: Joi.object({
    token: Joi.string().required(),
    newPassword: commonSchemas.password,
    confirmPassword: Joi.string().valid(Joi.ref('newPassword')).required(),
  }),
};

// Employee Validators
const employeeValidators = {
  create: Joi.object({
    firstName: Joi.string().min(2).required(),
    lastName: Joi.string().min(2).required(),
    email: commonSchemas.email,
    phone: commonSchemas.phone,
    dateOfBirth: Joi.date().iso().required(),
    gender: Joi.string().valid('male', 'female', 'other').required(),
    address: Joi.string().required(),
    city: Joi.string().required(),
    state: Joi.string().required(),
    zipCode: Joi.string().required(),
    country: Joi.string().required(),
    departmentId: Joi.number().integer().required(),
    designationId: Joi.number().integer().required(),
    salary: Joi.number().positive().required().messages({
      'number.positive': 'Salary must be a positive number',
    }),
    joinDate: Joi.date().iso().required(),
  }),

  update: Joi.object({
    firstName: Joi.string().min(2),
    lastName: Joi.string().min(2),
    phone: commonSchemas.phone,
    address: Joi.string(),
    city: Joi.string(),
    state: Joi.string(),
    zipCode: Joi.string(),
    country: Joi.string(),
    salary: Joi.number().positive(),
  }),

  list: Joi.object({
    ...commonSchemas.pagination,
    search: Joi.string().optional(),
    departmentId: Joi.number().optional(),
    sortBy: Joi.string().valid('firstName', 'lastName', 'email', 'salary', 'joinDate').default('firstName'),
    sortOrder: Joi.string().valid('asc', 'desc').default('asc'),
  }),
};

// Leave Validators
const leaveValidators = {
  create: Joi.object({
    employeeId: Joi.number().integer().required(),
    leaveTypeId: Joi.number().integer().required(),
    startDate: Joi.date().iso().required(),
    endDate: Joi.date().iso().required().min(Joi.ref('startDate')).messages({
      'date.min': 'End date must be after start date',
    }),
    reason: Joi.string().min(10).required(),
  }),

  update: Joi.object({
    startDate: Joi.date().iso(),
    endDate: Joi.date().iso().min(Joi.ref('startDate')),
    reason: Joi.string().min(10),
  }),

  approve: Joi.object({
    leaveId: Joi.number().integer().required(),
    approverComments: Joi.string().optional(),
  }),

  reject: Joi.object({
    leaveId: Joi.number().integer().required(),
    rejectionReason: Joi.string().min(10).required(),
  }),

  list: Joi.object({
    ...commonSchemas.pagination,
    status: Joi.string().valid('pending', 'approved', 'rejected', 'cancelled'),
    employeeId: Joi.number().integer(),
    sortBy: Joi.string().valid('startDate', 'createdAt', 'status').default('startDate'),
  }),
};

// Asset Validators
const assetValidators = {
  create: Joi.object({
    assetName: Joi.string().required(),
    assetCode: Joi.string().required(),
    category: Joi.string().required(),
    description: Joi.string().optional(),
    purchaseDate: Joi.date().iso().required(),
    purchasePrice: Joi.number().positive().required(),
    vendor: Joi.string().optional(),
    assignedTo: Joi.number().integer().optional(),
    status: Joi.string().valid('available', 'assigned', 'maintenance', 'retired').default('available'),
  }),

  update: Joi.object({
    assetName: Joi.string(),
    description: Joi.string(),
    status: Joi.string().valid('available', 'assigned', 'maintenance', 'retired'),
    assignedTo: Joi.number().integer(),
  }),

  list: Joi.object({
    ...commonSchemas.pagination,
    status: Joi.string().valid('available', 'assigned', 'maintenance', 'retired'),
    category: Joi.string(),
    search: Joi.string(),
    sortBy: Joi.string().valid('assetName', 'purchaseDate', 'purchasePrice').default('assetName'),
  }),
};

// Department Validators
const departmentValidators = {
  create: Joi.object({
    departmentName: Joi.string().min(2).required(),
    description: Joi.string().optional(),
    managerId: Joi.number().integer().required(),
  }),

  update: Joi.object({
    departmentName: Joi.string().min(2),
    description: Joi.string(),
    managerId: Joi.number().integer(),
  }),
};

// Report Validators
const reportValidators = {
  leaveReport: Joi.object({
    startDate: Joi.date().iso().required(),
    endDate: Joi.date().iso().min(Joi.ref('startDate')).required(),
    departmentId: Joi.number().integer().optional(),
  }),

  assetReport: Joi.object({
    category: Joi.string().optional(),
    status: Joi.string().valid('available', 'assigned', 'maintenance', 'retired'),
  }),
};

module.exports = {
  authValidators,
  employeeValidators,
  leaveValidators,
  assetValidators,
  departmentValidators,
  reportValidators,
};
