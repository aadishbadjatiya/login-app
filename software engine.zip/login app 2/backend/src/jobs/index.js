// Predefined Background Jobs
const jobManager = require('./jobManager');
const logger = require('../config/logger');
const config = require('../config/environment');
const { pool } = require('../config/database');

/**
 * Daily leave report job
 * Generates leave reports every day at 8 AM
 */
const dailyLeaveReport = async () => {
  try {
    const query = `
      SELECT 
        DATE(start_date) as date,
        COUNT(*) as total_leaves,
        SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved_leaves,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_leaves
      FROM leaves
      WHERE DATE(start_date) = CURRENT_DATE
      GROUP BY DATE(start_date)
    `;

    const result = await pool.query(query);
    logger.info('Daily leave report generated', { data: result.rows });
  } catch (error) {
    logger.error('Failed to generate daily leave report', { error: error.message });
  }
};

/**
 * Daily database backup job
 * Triggers backup at 2 AM daily
 */
const dailyDatabaseBackup = async () => {
  try {
    logger.info('Starting database backup...');
    // Implementation depends on your backup strategy
    // This could trigger pg_dump or another backup mechanism
    logger.info('Database backup completed');
  } catch (error) {
    logger.error('Database backup failed', { error: error.message });
  }
};

/**
 * Cleanup expired notifications
 * Runs every day at 3 AM
 */
const cleanupExpiredNotifications = async () => {
  try {
    const query = `
      DELETE FROM notifications
      WHERE created_at < NOW() - INTERVAL '30 days'
    `;

    const result = await pool.query(query);
    logger.info('Expired notifications cleaned up', { deletedRows: result.rowCount });
  } catch (error) {
    logger.error('Failed to cleanup notifications', { error: error.message });
  }
};

/**
 * Daily asset audit check
 * Runs every Monday at 9 AM
 */
const dailyAssetAuditCheck = async () => {
  try {
    const query = `
      SELECT 
        COUNT(*) as total_assets,
        SUM(CASE WHEN status = 'assigned' THEN 1 ELSE 0 END) as assigned_assets,
        SUM(CASE WHEN status = 'available' THEN 1 ELSE 0 END) as available_assets,
        SUM(CASE WHEN status = 'maintenance' THEN 1 ELSE 0 END) as maintenance_assets
      FROM assets
    `;

    const result = await pool.query(query);
    logger.info('Asset audit check completed', { data: result.rows[0] });
  } catch (error) {
    logger.error('Failed to complete asset audit check', { error: error.message });
  }
};

/**
 * Monthly payroll audit
 * Runs on the 1st of every month at 1 AM
 */
const monthlyPayrollAudit = async () => {
  try {
    const query = `
      SELECT 
        COUNT(*) as total_employees,
        SUM(salary) as total_payroll,
        AVG(salary) as average_salary,
        MIN(salary) as min_salary,
        MAX(salary) as max_salary
      FROM employees
      WHERE status = 'active'
    `;

    const result = await pool.query(query);
    logger.info('Monthly payroll audit completed', { data: result.rows[0] });
  } catch (error) {
    logger.error('Failed to complete payroll audit', { error: error.message });
  }
};

/**
 * Initialize all background jobs
 */
const initializeJobs = () => {
  logger.info('Initializing background jobs...');

  // Daily leave report at 8 AM (0 8 * * *)
  jobManager.scheduleJob('dailyLeaveReport', '0 8 * * *', dailyLeaveReport);

  // Daily database backup at 2 AM (0 2 * * *)
  jobManager.scheduleJob('dailyDatabaseBackup', '0 2 * * *', dailyDatabaseBackup);

  // Cleanup notifications daily at 3 AM (0 3 * * *)
  jobManager.scheduleJob('cleanupExpiredNotifications', '0 3 * * *', cleanupExpiredNotifications);

  // Asset audit every Monday at 9 AM (0 9 * * 1)
  jobManager.scheduleJob('dailyAssetAuditCheck', '0 9 * * 1', dailyAssetAuditCheck);

  // Monthly payroll audit on 1st of month at 1 AM (0 1 1 * *)
  jobManager.scheduleJob('monthlyPayrollAudit', '0 1 1 * *', monthlyPayrollAudit);

  logger.info('Background jobs initialized');
};

module.exports = {
  initializeJobs,
  jobManager,
  dailyLeaveReport,
  dailyDatabaseBackup,
  cleanupExpiredNotifications,
  dailyAssetAuditCheck,
  monthlyPayrollAudit,
};
