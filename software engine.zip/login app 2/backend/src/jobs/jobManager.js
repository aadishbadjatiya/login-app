// Background Jobs Manager using node-cron
const cron = require('node-cron');
const logger = require('../config/logger');

class JobManager {
  constructor() {
    this.jobs = new Map();
  }

  /**
   * Schedule a job to run at specific times
   * @param {string} jobName - Unique job name
   * @param {string} cronExpression - Cron expression (e.g., '0 0 * * *' for daily)
   * @param {Function} jobFunction - Async function to execute
   */
  scheduleJob(jobName, cronExpression, jobFunction) {
    try {
      // Check if job already exists
      if (this.jobs.has(jobName)) {
        logger.warn(`Job "${jobName}" already scheduled`);
        return false;
      }

      const task = cron.schedule(cronExpression, async () => {
        try {
          logger.info(`Starting job: ${jobName}`);
          const startTime = Date.now();

          await jobFunction();

          const duration = Date.now() - startTime;
          logger.info(`Job completed: ${jobName}`, { duration: `${duration}ms` });
        } catch (error) {
          logger.error(`Job failed: ${jobName}`, {
            error: error.message,
            stack: error.stack,
          });
        }
      });

      this.jobs.set(jobName, { task, expression: cronExpression, active: true });
      logger.info(`Job scheduled: ${jobName}`, { expression: cronExpression });

      return true;
    } catch (error) {
      logger.error(`Failed to schedule job: ${jobName}`, { error: error.message });
      return false;
    }
  }

  /**
   * Stop a scheduled job
   */
  stopJob(jobName) {
    const job = this.jobs.get(jobName);
    if (!job) {
      logger.warn(`Job "${jobName}" not found`);
      return false;
    }

    job.task.stop();
    job.active = false;
    logger.info(`Job stopped: ${jobName}`);
    return true;
  }

  /**
   * Resume a stopped job
   */
  resumeJob(jobName) {
    const job = this.jobs.get(jobName);
    if (!job) {
      logger.warn(`Job "${jobName}" not found`);
      return false;
    }

    job.task.start();
    job.active = true;
    logger.info(`Job resumed: ${jobName}`);
    return true;
  }

  /**
   * Get all scheduled jobs
   */
  getJobs() {
    return Array.from(this.jobs.entries()).map(([name, data]) => ({
      name,
      expression: data.expression,
      active: data.active,
    }));
  }

  /**
   * Stop all jobs
   */
  stopAllJobs() {
    this.jobs.forEach((job, name) => {
      job.task.stop();
      logger.info(`Job stopped: ${name}`);
    });
  }
}

// Export singleton
const jobManager = new JobManager();

module.exports = jobManager;
