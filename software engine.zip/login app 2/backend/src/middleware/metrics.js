// Request Metrics Middleware for monitoring
const logger = require('../config/logger');
const healthMonitor = require('../utils/healthMonitor');

/**
 * Middleware to track request metrics
 */
const metricsMiddleware = (req, res, next) => {
  const startTime = Date.now();

  // Track response
  const originalSend = res.send;
  res.send = function (data) {
    const responseTime = Date.now() - startTime;
    const hasError = res.statusCode >= 400;

    // Record metrics
    healthMonitor.recordRequest(responseTime, hasError);

    // Log request
    logger.http('HTTP Request', {
      method: req.method,
      path: req.path,
      statusCode: res.statusCode,
      responseTime: `${responseTime}ms`,
      userAgent: req.get('user-agent'),
      ip: req.ip,
      userId: req.user?.id,
    });

    // Call original send
    return originalSend.call(this, data);
  };

  next();
};

module.exports = metricsMiddleware;
