// Centralized Error Handler Middleware
const logger = require('../config/logger');
const { HTTP_CODES, ERROR_MESSAGES } = require('../constants');

// Custom Application Error Class
class AppError extends Error {
  constructor(message, statusCode = 500, code = null) {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
    this.isOperational = true;

    Error.captureStackTrace(this, this.constructor);
  }
}

// Global Error Handler Middleware
const errorHandler = (err, req, res, next) => {
  err.statusCode = err.statusCode || HTTP_CODES.INTERNAL_SERVER_ERROR;
  err.message = err.message || ERROR_MESSAGES.INTERNAL_ERROR;

  // Wrong MongoDB ID error
  if (err.name === 'CastError') {
    const message = `Invalid ${err.path}: ${err.value}`;
    err.statusCode = HTTP_CODES.BAD_REQUEST;
    err.message = message;
  }

  // Duplicate Key Error
  if (err.code === 11000) {
    const field = Object.keys(err.keyValue)[0];
    err.message = `${field.charAt(0).toUpperCase() + field.slice(1)} already exists`;
    err.statusCode = HTTP_CODES.CONFLICT;
  }

  // JWT Error
  if (err.name === 'JsonWebTokenError') {
    err.message = ERROR_MESSAGES.TOKEN_INVALID;
    err.statusCode = HTTP_CODES.UNAUTHORIZED;
  }

  if (err.name === 'TokenExpiredError') {
    err.message = ERROR_MESSAGES.TOKEN_EXPIRED;
    err.statusCode = HTTP_CODES.UNAUTHORIZED;
  }

  // Joi Validation Error
  if (err.isJoi) {
    const messages = err.details.map(detail => detail.message).join(', ');
    err.message = messages;
    err.statusCode = HTTP_CODES.UNPROCESSABLE_ENTITY;
  }

  // Log error
  logger.error('Error occurred', {
    statusCode: err.statusCode,
    message: err.message,
    code: err.code,
    path: req.originalUrl,
    method: req.method,
    ip: req.ip,
    userId: req.user?.id,
    stack: err.stack,
  });

  // Send error response
  res.status(err.statusCode).json({
    success: false,
    statusCode: err.statusCode,
    message: err.message,
    code: err.code,
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
  });
};

// Catch Async Errors Wrapper
const catchAsync = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

module.exports = {
  AppError,
  errorHandler,
  catchAsync,
};
