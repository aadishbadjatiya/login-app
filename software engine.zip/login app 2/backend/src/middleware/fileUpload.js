// Multer Configuration for File Uploads
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const logger = require('../config/logger');
const config = require('../config/environment');

// Create uploads directory if it doesn't exist
const uploadsDir = config.UPLOAD.UPLOAD_DIR;
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Configure storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadsDir);
  },
  filename: (req, file, cb) => {
    const timestamp = Date.now();
    const random = Math.random().toString(36).substring(7);
    const ext = path.extname(file.originalname);
    const baseName = path.basename(file.originalname, ext);
    const filename = `${baseName}_${timestamp}_${random}${ext}`;
    cb(null, filename);
  },
});

// Configure file filter
const fileFilter = (req, file, cb) => {
  const allowedMimes = config.UPLOAD.ALLOWED_TYPES;

  if (allowedMimes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    const error = new Error(`Invalid file type. Allowed: ${allowedMimes.join(', ')}`);
    logger.warn('Invalid file type rejected', { mimetype: file.mimetype });
    cb(error, false);
  }
};

// Initialize multer
const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: config.UPLOAD.MAX_SIZE,
  },
});

module.exports = upload;
