// Validation Middleware Wrapper
const { HTTP_CODES } = require('../constants');
const logger = require('../config/logger');

/**
 * Middleware to validate request body, params, or query
 * @param {Object} schema - Joi validation schema
 * @param {string} source - 'body', 'params', or 'query'
 */
const validate = (schema, source = 'body') => {
  return (req, res, next) => {
    const { error, value } = schema.validate(req[source], {
      abortEarly: false,
      stripUnknown: true,
    });

    if (error) {
      const errors = error.details.map(detail => ({
        field: detail.path.join('.'),
        message: detail.message,
      }));

      logger.warn('Validation error', {
        path: req.originalUrl,
        method: req.method,
        errors,
      });

      return res.status(HTTP_CODES.UNPROCESSABLE_ENTITY).json({
        success: false,
        statusCode: HTTP_CODES.UNPROCESSABLE_ENTITY,
        message: 'Validation failed',
        errors,
      });
    }

    // Replace request property with validated value
    req[source] = value;
    next();
  };
};

module.exports = validate;
