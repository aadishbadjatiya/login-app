// Database Configuration
const { Pool } = require('pg');
const config = require('./environment');
const logger = require('./logger');

const pool = new Pool({
  connectionString: config.DB.URL,
  max: config.DB.POOL.max,
  min: config.DB.POOL.min,
  idle: 10000,
  connection_timeout: 30000,
});

pool.on('error', (err) => {
  logger.error('Unexpected error on idle client', { error: err.message });
  process.exit(-1);
});

pool.on('connect', () => {
  logger.debug('New database connection established');
});

// Test database connection
const testConnection = async () => {
  try {
    const result = await pool.query('SELECT NOW()');
    logger.info('Database connection successful', { timestamp: result.rows[0] });
    return true;
  } catch (error) {
    logger.error('Database connection failed', { error: error.message });
    return false;
  }
};

module.exports = {
  pool,
  query: (text, params) => pool.query(text, params),
  getClient: () => pool.connect(),
  testConnection,
};
