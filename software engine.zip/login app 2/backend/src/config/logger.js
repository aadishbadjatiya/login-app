// Winston Logger Configuration
const winston = require('winston');
const path = require('path');
const fs = require('fs');

const config = require('./environment');

// Create logs directory if it doesn't exist
const logsDir = config.LOG.DIR;
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir, { recursive: true });
}

// Define custom log levels
const customLevels = {
  levels: {
    fatal: 0,
    error: 1,
    warn: 2,
    info: 3,
    http: 4,
    debug: 5,
  },
  colors: {
    fatal: 'red',
    error: 'red',
    warn: 'yellow',
    info: 'green',
    http: 'magenta',
    debug: 'white',
  },
};

// Custom format for logs
const customFormat = winston.format.combine(
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
  winston.format.errors({ stack: true }),
  winston.format.splat(),
  winston.format.json(),
);

// Transport: Console (colorized in development)
const consoleTransport = new winston.transports.Console({
  level: config.LOG.LEVEL,
  format: winston.format.combine(
    winston.format.colorize({ colors: customLevels.colors }),
    winston.format.printf(({ level, message, timestamp, ...meta }) => {
      const metaStr = Object.keys(meta).length ? JSON.stringify(meta, null, 2) : '';
      return `${timestamp} [${level}]: ${message} ${metaStr}`;
    }),
  ),
});

// Transport: Error logs
const errorFileTransport = new winston.transports.File({
  filename: path.join(logsDir, 'error.log'),
  level: 'error',
  format: customFormat,
  maxsize: 5242880, // 5MB
  maxFiles: 5,
});

// Transport: Combined logs
const combinedFileTransport = new winston.transports.File({
  filename: path.join(logsDir, 'combined.log'),
  format: customFormat,
  maxsize: 5242880, // 5MB
  maxFiles: 5,
});

// Transport: API/HTTP logs
const httpFileTransport = new winston.transports.File({
  filename: path.join(logsDir, 'api.log'),
  level: 'http',
  format: customFormat,
  maxsize: 5242880, // 5MB
  maxFiles: 5,
});

// Create logger instance
const logger = winston.createLogger({
  levels: customLevels.levels,
  format: customFormat,
  transports: [
    consoleTransport,
    errorFileTransport,
    combinedFileTransport,
    httpFileTransport,
  ],
  exceptionHandlers: [
    new winston.transports.File({
      filename: path.join(logsDir, 'exceptions.log'),
      format: customFormat,
    }),
  ],
  rejectionHandlers: [
    new winston.transports.File({
      filename: path.join(logsDir, 'rejections.log'),
      format: customFormat,
    }),
  ],
});

// Don't log in test environment
if (config.NODE_ENV === 'test') {
  logger.silent = true;
}

module.exports = logger;
