// Environment-based Configuration
const dotenv = require('dotenv');
const path = require('path');

// Load environment-specific .env file
const env = process.env.NODE_ENV || 'development';
const envFile = path.resolve(__dirname, `../../.env.${env}`);

// Fallback to .env if environment-specific file doesn't exist
try {
  require('fs').accessSync(envFile);
  dotenv.config({ path: envFile });
} catch {
  console.warn(`${envFile} not found, using .env`);
  dotenv.config({ path: path.resolve(__dirname, '../../.env') });
}

const config = {
  // Server Configuration
  PORT: process.env.PORT || 4000,
  NODE_ENV: process.env.NODE_ENV || 'development',
  CLIENT_URL: process.env.CLIENT_URL || 'http://localhost:5173',

  // Database Configuration
  DB: {
    HOST: process.env.DB_HOST || 'localhost',
    PORT: process.env.DB_PORT || 5432,
    USER: process.env.DB_USER || 'postgres',
    PASSWORD: process.env.DB_PASSWORD || 'password',
    DATABASE: process.env.DB_NAME || 'workforce',
    URL: process.env.DATABASE_URL || 'postgres://postgres:password@localhost:5432/workforce',
    POOL: {
      min: process.env.DB_POOL_MIN || 2,
      max: process.env.DB_POOL_MAX || 10,
    },
  },

  // JWT Configuration
  JWT: {
    SECRET: process.env.JWT_SECRET || 'your-secret-key-change-in-production',
    EXPIRY: process.env.JWT_EXPIRY || '24h',
    REFRESH_SECRET: process.env.REFRESH_SECRET || 'refresh-secret-key',
    REFRESH_EXPIRY: process.env.REFRESH_EXPIRY || '7d',
  },

  // Email Configuration
  EMAIL: {
    HOST: process.env.EMAIL_HOST || 'smtp.gmail.com',
    PORT: process.env.EMAIL_PORT || 587,
    USER: process.env.EMAIL_USER || '',
    PASSWORD: process.env.EMAIL_PASSWORD || '',
    FROM: process.env.EMAIL_FROM || 'noreply@workforce.com',
  },

  // Logging Configuration
  LOG: {
    LEVEL: process.env.LOG_LEVEL || (process.env.NODE_ENV === 'production' ? 'warn' : 'info'),
    DIR: process.env.LOG_DIR || './src/logs',
  },

  // File Upload Configuration
  UPLOAD: {
    MAX_SIZE: process.env.UPLOAD_MAX_SIZE || 5242880, // 5MB
    ALLOWED_TYPES: (process.env.UPLOAD_ALLOWED_TYPES || 'image/jpeg,image/png,application/pdf').split(','),
    UPLOAD_DIR: process.env.UPLOAD_DIR || './uploads',
  },

  // Cache Configuration
  CACHE: {
    TTL: process.env.CACHE_TTL || 3600, // 1 hour in seconds
    ENABLED: process.env.CACHE_ENABLED !== 'false',
  },

  // Rate Limiting Configuration
  RATE_LIMIT: {
    WINDOW_MS: process.env.RATE_LIMIT_WINDOW_MS || 15 * 60 * 1000, // 15 minutes
    MAX_REQUESTS: process.env.RATE_LIMIT_MAX_REQUESTS || 100,
    AUTH_MAX_REQUESTS: process.env.AUTH_RATE_LIMIT_MAX_REQUESTS || 5,
  },

  // Pagination Configuration
  PAGINATION: {
    DEFAULT_PAGE: 1,
    DEFAULT_LIMIT: 10,
    MAX_LIMIT: 100,
  },

  // Is Development/Production/Staging
  isDev: process.env.NODE_ENV === 'development',
  isStaging: process.env.NODE_ENV === 'staging',
  isProd: process.env.NODE_ENV === 'production',
};

module.exports = config;
