// API v1 Routes Index
// This file will aggregate all v1 routes

module.exports = {
  // TODO: Export individual route modules
  // authRoutes: require('./auth'),
  // employeeRoutes: require('./employees'),
};
