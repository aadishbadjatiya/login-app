// API Router Configuration for Versioning
const express = require('express');

/**
 * Setup API versioned routes
 * Supports multiple API versions with backward compatibility
 */
const setupVersionedRoutes = (app) => {
  // API v1 routes
  const v1Router = express.Router();

  // Health endpoint under v1
  v1Router.get('/health', (req, res) => {
    res.json({
      success: true,
      status: 'UP',
      version: 'v1',
      timestamp: new Date().toISOString(),
    });
  });

  // TODO: Import and setup versioned routes
  // Example structure:
  // const authRoutesV1 = require('../routes/v1/auth');
  // const employeeRoutesV1 = require('../routes/v1/employees');
  // v1Router.use('/auth', authRoutesV1);
  // v1Router.use('/employees', employeeRoutesV1);

  // Register v1 routes
  app.use('/api/v1', v1Router);

  // API v2 routes (for future use)
  const v2Router = express.Router();
  v2Router.get('/health', (req, res) => {
    res.json({
      success: true,
      status: 'UP',
      version: 'v2',
      timestamp: new Date().toISOString(),
    });
  });
  // app.use('/api/v2', v2Router);

  return { v1Router, v2Router };
};

module.exports = setupVersionedRoutes;
