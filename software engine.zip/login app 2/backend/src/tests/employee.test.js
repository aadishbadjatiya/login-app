// Unit Tests for Employee Service
const { pool } = require('../../config/database');
const logger = require('../../config/logger');

describe('EmployeeService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('getAllEmployees', () => {
    it('should fetch all employees successfully', async () => {
      const mockEmployees = [
        { id: 1, first_name: 'John', last_name: 'Doe', email: 'john@example.com' },
        { id: 2, first_name: 'Jane', last_name: 'Smith', email: 'jane@example.com' },
      ];

      pool.query.mockResolvedValue({ rows: mockEmployees, rowCount: 2 });

      expect(pool.query).toBeDefined();
    });

    it('should return empty array when no employees exist', async () => {
      pool.query.mockResolvedValue({ rows: [], rowCount: 0 });

      expect(pool.query).toBeDefined();
    });
  });

  describe('createEmployee', () => {
    it('should create employee successfully', async () => {
      const employeeData = {
        first_name: 'John',
        last_name: 'Doe',
        email: 'john@example.com',
        department_id: 1,
        salary: 50000,
      };

      pool.query.mockResolvedValue({
        rows: [{ id: 1, ...employeeData }],
        rowCount: 1,
      });

      expect(pool.query).toBeDefined();
    });

    it('should fail with duplicate email', async () => {
      pool.query.mockRejectedValue({ code: '23505' }); // Unique constraint violation

      expect(pool.query).toBeDefined();
    });
  });

  describe('updateEmployee', () => {
    it('should update employee successfully', async () => {
      const updateData = { salary: 60000 };

      pool.query.mockResolvedValue({
        rows: [{ id: 1, ...updateData }],
        rowCount: 1,
      });

      expect(pool.query).toBeDefined();
    });

    it('should fail if employee not found', async () => {
      pool.query.mockResolvedValue({ rows: [], rowCount: 0 });

      expect(pool.query).toBeDefined();
    });
  });

  describe('deleteEmployee', () => {
    it('should delete employee successfully', async () => {
      pool.query.mockResolvedValue({ rowCount: 1 });

      expect(pool.query).toBeDefined();
    });

    it('should return 0 if employee not found', async () => {
      pool.query.mockResolvedValue({ rowCount: 0 });

      expect(pool.query).toBeDefined();
    });
  });
});
