// Caching System using node-cache
const NodeCache = require('node-cache');
const logger = require('../config/logger');
const config = require('../config/environment');

class CacheManager {
  constructor() {
    this.cache = new NodeCache({
      stdTTL: config.CACHE.TTL,
      checkperiod: 120,
      useClones: false,
    });

    // Cache statistics
    this.stats = {
      hits: 0,
      misses: 0,
      sets: 0,
      deletes: 0,
    };

    // Monitor cache events
    this.cache.on('expired', (key) => {
      logger.debug('Cache expired', { key });
    });

    this.cache.on('del', (key) => {
      logger.debug('Cache deleted', { key });
    });
  }

  /**
   * Get value from cache
   */
  get(key) {
    if (!config.CACHE.ENABLED) return null;

    const value = this.cache.get(key);
    if (value) {
      this.stats.hits++;
      logger.debug('Cache hit', { key });
    } else {
      this.stats.misses++;
      logger.debug('Cache miss', { key });
    }
    return value;
  }

  /**
   * Set value in cache
   */
  set(key, value, ttl = config.CACHE.TTL) {
    if (!config.CACHE.ENABLED) return false;

    this.cache.set(key, value, ttl);
    this.stats.sets++;
    logger.debug('Cache set', { key, ttl });
    return true;
  }

  /**
   * Delete key from cache
   */
  delete(key) {
    if (!config.CACHE.ENABLED) return false;

    this.cache.del(key);
    this.stats.deletes++;
    logger.debug('Cache deleted', { key });
    return true;
  }

  /**
   * Delete multiple keys
   */
  deleteMany(keys) {
    if (!config.CACHE.ENABLED) return false;

    this.cache.del(keys);
    this.stats.deletes += keys.length;
    logger.debug('Cache deleted multiple', { count: keys.length });
    return true;
  }

  /**
   * Clear all cache
   */
  clear() {
    this.cache.flushAll();
    logger.info('Cache cleared');
    return true;
  }

  /**
   * Get cache keys
   */
  keys() {
    return this.cache.keys();
  }

  /**
   * Get cache statistics
   */
  getStats() {
    const keys = this.cache.keys();
    return {
      ...this.stats,
      totalKeys: keys.length,
      hitRate: this.stats.hits / (this.stats.hits + this.stats.misses) || 0,
    };
  }

  /**
   * Invalidate cache pattern (e.g., 'employees:*')
   */
  invalidatePattern(pattern) {
    if (!config.CACHE.ENABLED) return false;

    const keys = this.cache.keys();
    const regex = new RegExp(pattern.replace('*', '.*'));
    const keysToDelete = keys.filter(key => regex.test(key));

    if (keysToDelete.length > 0) {
      this.cache.del(keysToDelete);
      this.stats.deletes += keysToDelete.length;
      logger.debug('Cache pattern invalidated', { pattern, count: keysToDelete.length });
    }

    return true;
  }
}

// Export singleton instance
module.exports = new CacheManager();
