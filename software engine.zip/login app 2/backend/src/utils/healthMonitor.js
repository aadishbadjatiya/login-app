// Monitoring and Health Check Utilities
const logger = require('../config/logger');
const { pool } = require('../config/database');
const config = require('../config/environment');
const cacheManager = require('./cache');

class HealthMonitor {
  constructor() {
    this.startTime = Date.now();
    this.metrics = {
      totalRequests: 0,
      totalErrors: 0,
      totalResponseTime: 0,
      averageResponseTime: 0,
    };
  }

  /**
   * Get comprehensive health status
   */
  async getHealthStatus() {
    const dbHealth = await this.checkDatabaseHealth();
    const cacheHealth = this.checkCacheHealth();
    const systemHealth = this.getSystemHealth();

    const overallStatus = dbHealth.healthy && systemHealth.healthy ? 'UP' : 'DEGRADED';

    return {
      status: overallStatus,
      timestamp: new Date().toISOString(),
      uptime: this.getUptime(),
      environment: config.NODE_ENV,
      version: '1.0.0',
      services: {
        database: dbHealth,
        cache: cacheHealth,
        system: systemHealth,
      },
      metrics: this.metrics,
    };
  }

  /**
   * Check database connectivity and health
   */
  async checkDatabaseHealth() {
    try {
      const startTime = Date.now();
      const result = await pool.query('SELECT NOW()');
      const responseTime = Date.now() - startTime;

      return {
        status: 'UP',
        responseTime: `${responseTime}ms`,
        lastChecked: new Date().toISOString(),
        details: {
          connected: true,
          database: config.DB.DATABASE,
          host: config.DB.HOST,
        },
        healthy: true,
      };
    } catch (error) {
      logger.error('Database health check failed', { error: error.message });
      return {
        status: 'DOWN',
        error: error.message,
        lastChecked: new Date().toISOString(),
        healthy: false,
      };
    }
  }

  /**
   * Check cache health
   */
  checkCacheHealth() {
    try {
      const stats = cacheManager.getStats();

      return {
        status: 'UP',
        enabled: config.CACHE.ENABLED,
        keys: stats.totalKeys,
        hitRate: (stats.hitRate * 100).toFixed(2) + '%',
        stats,
        healthy: true,
      };
    } catch (error) {
      logger.error('Cache health check failed', { error: error.message });
      return {
        status: 'DOWN',
        error: error.message,
        healthy: false,
      };
    }
  }

  /**
   * Get system health metrics
   */
  getSystemHealth() {
    const memUsage = process.memoryUsage();
    const uptime = process.uptime();

    const cpuUsage = process.cpuUsage();

    return {
      status: 'UP',
      uptime: `${Math.floor(uptime / 3600)}h ${Math.floor((uptime % 3600) / 60)}m ${Math.floor(uptime % 60)}s`,
      memory: {
        rss: `${(memUsage.rss / 1024 / 1024).toFixed(2)} MB`,
        heapTotal: `${(memUsage.heapTotal / 1024 / 1024).toFixed(2)} MB`,
        heapUsed: `${(memUsage.heapUsed / 1024 / 1024).toFixed(2)} MB`,
        external: `${(memUsage.external / 1024 / 1024).toFixed(2)} MB`,
      },
      cpu: {
        user: cpuUsage.user,
        system: cpuUsage.system,
      },
      nodeVersion: process.version,
      healthy: true,
    };
  }

  /**
   * Get uptime in human-readable format
   */
  getUptime() {
    const uptime = (Date.now() - this.startTime) / 1000;
    const days = Math.floor(uptime / 86400);
    const hours = Math.floor((uptime % 86400) / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);

    return `${days}d ${hours}h ${minutes}m ${seconds}s`;
  }

  /**
   * Record request metrics
   */
  recordRequest(responseTime, hasError = false) {
    this.metrics.totalRequests++;
    this.metrics.totalResponseTime += responseTime;
    this.metrics.averageResponseTime = this.metrics.totalResponseTime / this.metrics.totalRequests;

    if (hasError) {
      this.metrics.totalErrors++;
    }
  }

  /**
   * Get metrics summary
   */
  getMetrics() {
    const errorRate = ((this.metrics.totalErrors / this.metrics.totalRequests) * 100).toFixed(2);

    return {
      totalRequests: this.metrics.totalRequests,
      totalErrors: this.metrics.totalErrors,
      errorRate: `${errorRate}%`,
      averageResponseTime: `${this.metrics.averageResponseTime.toFixed(2)}ms`,
      uptime: this.getUptime(),
    };
  }
}

module.exports = new HealthMonitor();
