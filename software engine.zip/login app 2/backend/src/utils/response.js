// Response Formatter Utility
const { HTTP_CODES } = require('../constants');

/**
 * Format successful response
 */
const success = (data = null, message = 'Success', statusCode = HTTP_CODES.OK) => {
  return {
    success: true,
    statusCode,
    message,
    data,
    timestamp: new Date().toISOString(),
  };
};

/**
 * Format error response
 */
const error = (message = 'Error', statusCode = HTTP_CODES.INTERNAL_SERVER_ERROR, errors = null) => {
  return {
    success: false,
    statusCode,
    message,
    errors,
    timestamp: new Date().toISOString(),
  };
};

/**
 * Format paginated response
 */
const paginated = (data = [], pagination = {}, message = 'Success', statusCode = HTTP_CODES.OK) => {
  return {
    success: true,
    statusCode,
    message,
    data,
    pagination: {
      page: pagination.page || 1,
      limit: pagination.limit || 10,
      total: pagination.total || 0,
      pages: pagination.pages || Math.ceil((pagination.total || 0) / (pagination.limit || 10)),
    },
    timestamp: new Date().toISOString(),
  };
};

module.exports = {
  success,
  error,
  paginated,
};
