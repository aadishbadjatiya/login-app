// Pagination Utility
const { PAGINATION_DEFAULTS } = require('../constants');

/**
 * Parse pagination parameters from request query
 */
const getPaginationParams = (query) => {
  const page = Math.max(1, parseInt(query.page || PAGINATION_DEFAULTS.PAGE, 10));
  const limit = Math.min(
    parseInt(query.limit || PAGINATION_DEFAULTS.LIMIT, 10),
    PAGINATION_DEFAULTS.MAX_LIMIT
  );

  return {
    page,
    limit,
    offset: (page - 1) * limit,
  };
};

/**
 * Calculate pagination metadata
 */
const getPaginationMeta = (total, page, limit) => {
  return {
    page,
    limit,
    total,
    pages: Math.ceil(total / limit),
    hasNextPage: page < Math.ceil(total / limit),
    hasPrevPage: page > 1,
  };
};

module.exports = {
  getPaginationParams,
  getPaginationMeta,
};
