// Sorting and Filtering Utilities

/**
 * Build sort clause for database queries
 */
const buildSortClause = (sortBy, sortOrder = 'asc', allowedFields = []) => {
  // Validate sort field
  if (!allowedFields.includes(sortBy)) {
    return 'ORDER BY id ASC';
  }

  // Validate sort order
  const order = ['asc', 'desc'].includes(sortOrder.toLowerCase()) ? sortOrder.toUpperCase() : 'ASC';

  return `ORDER BY ${sortBy} ${order}`;
};

/**
 * Build filter clause for database queries
 * @param {Object} filters - Filter conditions
 * @param {Array} allowedFilters - Allowed filter fields
 * @returns {Object} { whereClause, params }
 */
const buildFilterClause = (filters = {}, allowedFilters = []) => {
  const conditions = [];
  const params = [];
  let paramIndex = 1;

  Object.entries(filters).forEach(([key, value]) => {
    if (!allowedFilters.includes(key) || value === undefined || value === null) {
      return;
    }

    // Handle array values (IN operator)
    if (Array.isArray(value)) {
      const placeholders = value.map(() => `$${paramIndex++}`).join(',');
      conditions.push(`${key} IN (${placeholders})`);
      params.push(...value);
    }
    // Handle date ranges
    else if (key.includes('_from') || key.includes('_start')) {
      conditions.push(`${key} >= $${paramIndex++}`);
      params.push(value);
    }
    // Handle date ranges (to)
    else if (key.includes('_to') || key.includes('_end')) {
      conditions.push(`${key} <= $${paramIndex++}`);
      params.push(value);
    }
    // Handle regular equality
    else {
      conditions.push(`${key} = $${paramIndex++}`);
      params.push(value);
    }
  });

  const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

  return { whereClause, params };
};

/**
 * Employee filter example - shows expected format
 */
const employeeFilters = {
  allowedFields: ['id', 'first_name', 'last_name', 'email', 'department_id', 'salary', 'join_date'],
  allowedFilters: ['department_id', 'status', 'join_date_from', 'join_date_to', 'salary_from', 'salary_to'],
  allowedSortFields: ['first_name', 'last_name', 'email', 'salary', 'join_date'],
};

/**
 * Asset filter example
 */
const assetFilters = {
  allowedFields: ['id', 'asset_name', 'asset_code', 'category', 'status', 'assigned_to'],
  allowedFilters: ['category', 'status', 'assigned_to'],
  allowedSortFields: ['asset_name', 'category', 'status', 'purchase_date', 'purchase_price'],
};

/**
 * Leave filter example
 */
const leaveFilters = {
  allowedFields: ['id', 'employee_id', 'leave_type_id', 'start_date', 'end_date', 'status'],
  allowedFilters: ['status', 'employee_id', 'leave_type_id', 'start_date_from', 'start_date_to'],
  allowedSortFields: ['start_date', 'end_date', 'created_at', 'status'],
};

/**
 * Build complete query with filters, sort, and pagination
 */
const buildCompleteQuery = (baseQuery, filters, sorting, pagination) => {
  let query = baseQuery;
  const params = [];

  // Add filters
  if (filters && Object.keys(filters).length > 0) {
    const { whereClause, params: filterParams } = buildFilterClause(filters.filters, filters.allowedFilters);
    if (whereClause) {
      query += ` ${whereClause}`;
      params.push(...filterParams);
    }
  }

  // Add sorting
  if (sorting) {
    const sortClause = buildSortClause(sorting.sortBy, sorting.sortOrder, sorting.allowedFields);
    query += ` ${sortClause}`;
  }

  // Add pagination
  if (pagination) {
    const offset = (pagination.page - 1) * pagination.limit;
    query += ` LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
    params.push(pagination.limit, offset);
  }

  return { query, params };
};

/**
 * Parse query parameters for filtering, sorting, and pagination
 */
const parseQueryParams = (queryParams, config) => {
  return {
    filters: {
      filters: queryParams,
      allowedFilters: config.allowedFilters || [],
    },
    sorting: {
      sortBy: queryParams.sortBy || config.defaultSort || 'id',
      sortOrder: queryParams.sortOrder || 'asc',
      allowedFields: config.allowedSortFields || [],
    },
    pagination: {
      page: Math.max(1, parseInt(queryParams.page || 1, 10)),
      limit: Math.min(parseInt(queryParams.limit || 10, 10), 100),
    },
  };
};

module.exports = {
  buildSortClause,
  buildFilterClause,
  buildCompleteQuery,
  parseQueryParams,
  employeeFilters,
  assetFilters,
  leaveFilters,
};
