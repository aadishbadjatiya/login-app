// Search Utility for filtering and searching
const { Op } = require('sequelize'); // For future ORM migration

/**
 * Build search conditions for database queries
 */
const buildSearchConditions = (searchTerm, searchableFields) => {
  if (!searchTerm || !searchableFields || searchableFields.length === 0) {
    return null;
  }

  // For PostgreSQL ILIKE (case-insensitive)
  const conditions = searchableFields.map(field => ({
    [field]: { $iLike: `%${searchTerm}%` },
  }));

  return conditions.length === 1 ? conditions[0] : { $or: conditions };
};

/**
 * Build WHERE clause for PostgreSQL raw query
 */
const buildPostgresSearchCondition = (searchTerm, searchableFields) => {
  if (!searchTerm || !searchableFields || searchableFields.length === 0) {
    return '';
  }

  const conditions = searchableFields.map(
    field => `CAST(${field} AS TEXT) ILIKE $1`
  );

  return `WHERE ${conditions.join(' OR ')}`;
};

/**
 * Search employee records
 * @param {Object} pool - Database pool
 * @param {string} searchTerm - Search term
 * @param {number} page - Page number
 * @param {number} limit - Records per page
 * @returns {Promise} Search results with pagination
 */
const searchEmployees = async (pool, searchTerm, page = 1, limit = 10) => {
  const offset = (page - 1) * limit;
  const searchPattern = `%${searchTerm}%`;

  const query = `
    SELECT id, first_name, last_name, email, phone, department_id, salary, join_date
    FROM employees
    WHERE first_name ILIKE $1 
      OR last_name ILIKE $1 
      OR email ILIKE $1 
      OR phone ILIKE $1
    ORDER BY first_name ASC
    LIMIT $2 OFFSET $3
  `;

  const countQuery = `
    SELECT COUNT(*) as total
    FROM employees
    WHERE first_name ILIKE $1 
      OR last_name ILIKE $1 
      OR email ILIKE $1 
      OR phone ILIKE $1
  `;

  try {
    const results = await pool.query(query, [searchPattern, limit, offset]);
    const countResult = await pool.query(countQuery, [searchPattern]);
    const total = parseInt(countResult.rows[0].total, 10);

    return {
      data: results.rows,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    };
  } catch (error) {
    throw new Error(`Search employees failed: ${error.message}`);
  }
};

/**
 * Search assets
 */
const searchAssets = async (pool, searchTerm, page = 1, limit = 10) => {
  const offset = (page - 1) * limit;
  const searchPattern = `%${searchTerm}%`;

  const query = `
    SELECT id, asset_name, asset_code, category, status, assigned_to
    FROM assets
    WHERE asset_name ILIKE $1 
      OR asset_code ILIKE $1 
      OR category ILIKE $1
    ORDER BY asset_name ASC
    LIMIT $2 OFFSET $3
  `;

  const countQuery = `
    SELECT COUNT(*) as total
    FROM assets
    WHERE asset_name ILIKE $1 
      OR asset_code ILIKE $1 
      OR category ILIKE $1
  `;

  try {
    const results = await pool.query(query, [searchPattern, limit, offset]);
    const countResult = await pool.query(countQuery, [searchPattern]);
    const total = parseInt(countResult.rows[0].total, 10);

    return {
      data: results.rows,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    };
  } catch (error) {
    throw new Error(`Search assets failed: ${error.message}`);
  }
};

/**
 * Search leaves
 */
const searchLeaves = async (pool, searchTerm, page = 1, limit = 10) => {
  const offset = (page - 1) * limit;
  const searchPattern = `%${searchTerm}%`;

  const query = `
    SELECT l.id, l.employee_id, l.leave_type_id, l.start_date, l.end_date, l.status, e.first_name, e.last_name
    FROM leaves l
    JOIN employees e ON l.employee_id = e.id
    WHERE e.first_name ILIKE $1 
      OR e.last_name ILIKE $1 
      OR l.reason ILIKE $1
    ORDER BY l.start_date DESC
    LIMIT $2 OFFSET $3
  `;

  const countQuery = `
    SELECT COUNT(*) as total
    FROM leaves l
    JOIN employees e ON l.employee_id = e.id
    WHERE e.first_name ILIKE $1 
      OR e.last_name ILIKE $1 
      OR l.reason ILIKE $1
  `;

  try {
    const results = await pool.query(query, [searchPattern, limit, offset]);
    const countResult = await pool.query(countQuery, [searchPattern]);
    const total = parseInt(countResult.rows[0].total, 10);

    return {
      data: results.rows,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    };
  } catch (error) {
    throw new Error(`Search leaves failed: ${error.message}`);
  }
};

module.exports = {
  buildSearchConditions,
  buildPostgresSearchCondition,
  searchEmployees,
  searchAssets,
  searchLeaves,
};
