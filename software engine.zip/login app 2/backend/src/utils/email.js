// Email Service using Nodemailer
const nodemailer = require('nodemailer');
const logger = require('../config/logger');
const config = require('../config/environment');

class EmailService {
  constructor() {
    // Initialize transporter
    this.transporter = nodemailer.createTransport({
      host: config.EMAIL.HOST,
      port: config.EMAIL.PORT,
      secure: config.EMAIL.PORT === 465, // true for 465, false for other ports
      auth: {
        user: config.EMAIL.USER,
        pass: config.EMAIL.PASSWORD,
      },
    });

    // Verify connection (non-blocking)
    this.transporter.verify((error) => {
      if (error) {
        logger.error('Email transporter verification failed', { error: error.message });
      } else {
        logger.info('Email transporter is ready to send emails');
      }
    });
  }

  /**
   * Send generic email
   */
  async sendEmail(to, subject, htmlContent, textContent = '') {
    try {
      const mailOptions = {
        from: config.EMAIL.FROM,
        to,
        subject,
        html: htmlContent,
        text: textContent,
      };

      const info = await this.transporter.sendMail(mailOptions);
      logger.info('Email sent successfully', {
        messageId: info.messageId,
        to,
        subject,
      });

      return { success: true, messageId: info.messageId };
    } catch (error) {
      logger.error('Failed to send email', {
        to,
        subject,
        error: error.message,
      });

      return { success: false, error: error.message };
    }
  }

  /**
   * Welcome email for new users
   */
  async sendWelcomeEmail(userEmail, userName) {
    const subject = 'Welcome to WorkForce HR Management System';
    const htmlContent = `
      <h1>Welcome to WorkForce!</h1>
      <p>Hi ${userName},</p>
      <p>Your account has been created successfully. You can now log in to the system.</p>
      <p>If you have any questions, please contact our support team.</p>
      <br>
      <p>Best regards,</p>
      <p>WorkForce Team</p>
    `;

    return this.sendEmail(userEmail, subject, htmlContent);
  }

  /**
   * Leave approval email
   */
  async sendLeaveApprovalEmail(employeeEmail, employeeName, leaveDetails) {
    const subject = 'Leave Request Approved';
    const htmlContent = `
      <h1>Leave Request Approved</h1>
      <p>Hi ${employeeName},</p>
      <p>Your leave request has been approved.</p>
      <ul>
        <li><strong>From:</strong> ${leaveDetails.startDate}</li>
        <li><strong>To:</strong> ${leaveDetails.endDate}</li>
        <li><strong>Type:</strong> ${leaveDetails.leaveType}</li>
        <li><strong>Days:</strong> ${leaveDetails.days}</li>
      </ul>
      <p>Approved by: ${leaveDetails.approverName}</p>
      <br>
      <p>Best regards,</p>
      <p>HR Team</p>
    `;

    return this.sendEmail(employeeEmail, subject, htmlContent);
  }

  /**
   * Leave rejection email
   */
  async sendLeaveRejectionEmail(employeeEmail, employeeName, leaveDetails, rejectionReason) {
    const subject = 'Leave Request Rejected';
    const htmlContent = `
      <h1>Leave Request Rejected</h1>
      <p>Hi ${employeeName},</p>
      <p>Unfortunately, your leave request has been rejected.</p>
      <ul>
        <li><strong>From:</strong> ${leaveDetails.startDate}</li>
        <li><strong>To:</strong> ${leaveDetails.endDate}</li>
        <li><strong>Type:</strong> ${leaveDetails.leaveType}</li>
      </ul>
      <p><strong>Reason:</strong> ${rejectionReason}</p>
      <p>Please contact HR for more details.</p>
      <br>
      <p>Best regards,</p>
      <p>HR Team</p>
    `;

    return this.sendEmail(employeeEmail, subject, htmlContent);
  }

  /**
   * Asset assignment email
   */
  async sendAssetAssignmentEmail(employeeEmail, employeeName, assetDetails) {
    const subject = 'Asset Assigned to You';
    const htmlContent = `
      <h1>Asset Assignment Notification</h1>
      <p>Hi ${employeeName},</p>
      <p>An asset has been assigned to you.</p>
      <ul>
        <li><strong>Asset Name:</strong> ${assetDetails.assetName}</li>
        <li><strong>Asset Code:</strong> ${assetDetails.assetCode}</li>
        <li><strong>Category:</strong> ${assetDetails.category}</li>
        <li><strong>Assignment Date:</strong> ${assetDetails.assignmentDate}</li>
      </ul>
      <p>Please acknowledge receipt and ensure proper care of the asset.</p>
      <br>
      <p>Best regards,</p>
      <p>Asset Management Team</p>
    `;

    return this.sendEmail(employeeEmail, subject, htmlContent);
  }

  /**
   * Password reset email
   */
  async sendPasswordResetEmail(userEmail, resetLink) {
    const subject = 'Password Reset Request';
    const htmlContent = `
      <h1>Password Reset</h1>
      <p>We received a request to reset your password.</p>
      <p>Click the link below to reset your password:</p>
      <a href="${resetLink}" style="display: inline-block; padding: 10px 20px; background-color: #007bff; color: white; text-decoration: none; border-radius: 5px;">
        Reset Password
      </a>
      <p>This link will expire in 1 hour.</p>
      <p>If you didn't request this, please ignore this email.</p>
      <br>
      <p>Best regards,</p>
      <p>WorkForce Team</p>
    `;

    return this.sendEmail(userEmail, subject, htmlContent);
  }

  /**
   * Bulk email sender (for notifications)
   */
  async sendBulkEmail(recipients, subject, htmlContent, textContent = '') {
    const results = [];

    for (const email of recipients) {
      const result = await this.sendEmail(email, subject, htmlContent, textContent);
      results.push({ email, ...result });
    }

    logger.info('Bulk email sending completed', {
      totalRecipients: recipients.length,
      successCount: results.filter(r => r.success).length,
    });

    return results;
  }
}

// Export singleton instance
module.exports = new EmailService();
