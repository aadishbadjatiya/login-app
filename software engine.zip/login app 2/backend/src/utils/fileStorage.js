// File Upload Validator and Storage Manager
const fs = require('fs');
const path = require('path');
const logger = require('../config/logger');
const config = require('../config/environment');

class FileStorageManager {
  constructor() {
    this.uploadDir = config.UPLOAD.UPLOAD_DIR;
    this.maxSize = config.UPLOAD.MAX_SIZE;
    this.allowedTypes = config.UPLOAD.ALLOWED_TYPES;

    // Create storage directories if they don't exist
    this.initializeDirectories();
  }

  /**
   * Initialize storage directory structure
   */
  initializeDirectories() {
    const dirs = [
      path.join(this.uploadDir),
      path.join(this.uploadDir, 'employees'),
      path.join(this.uploadDir, 'documents'),
      path.join(this.uploadDir, 'certificates'),
      path.join(this.uploadDir, 'assets'),
    ];

    dirs.forEach(dir => {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
        logger.info(`Storage directory created: ${dir}`);
      }
    });
  }

  /**
   * Validate file before upload
   */
  validateFile(file, allowedMimeTypes = null) {
    const errors = [];

    // Check if file exists
    if (!file) {
      errors.push('No file provided');
      return { valid: false, errors };
    }

    // Check file size
    if (file.size > this.maxSize) {
      errors.push(`File size exceeds maximum limit of ${this.maxSize / 1024 / 1024}MB`);
    }

    // Check MIME type
    const mimeTypes = allowedMimeTypes || this.allowedTypes;
    if (!mimeTypes.includes(file.mimetype)) {
      errors.push(`File type ${file.mimetype} is not allowed. Allowed types: ${mimeTypes.join(', ')}`);
    }

    // Check file extension
    const allowedExtensions = ['jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx'];
    const fileExt = path.extname(file.originalname).toLowerCase().slice(1);
    if (!allowedExtensions.includes(fileExt)) {
      errors.push(`File extension .${fileExt} is not allowed`);
    }

    return {
      valid: errors.length === 0,
      errors,
    };
  }

  /**
   * Generate unique filename
   */
  generateFilename(originalName, prefix = '') {
    const timestamp = Date.now();
    const random = Math.random().toString(36).substring(7);
    const ext = path.extname(originalName);
    const baseName = path.basename(originalName, ext);

    return `${prefix ? prefix + '_' : ''}${baseName}_${timestamp}_${random}${ext}`;
  }

  /**
   * Save file to appropriate directory
   */
  saveFile(file, category = 'documents') {
    try {
      const validation = this.validateFile(file);
      if (!validation.valid) {
        return { success: false, errors: validation.errors };
      }

      const categoryDir = path.join(this.uploadDir, category);
      if (!fs.existsSync(categoryDir)) {
        fs.mkdirSync(categoryDir, { recursive: true });
      }

      const filename = this.generateFilename(file.originalname, category);
      const filepath = path.join(categoryDir, filename);

      // Save file (file.path from multer has the temporary location)
      fs.copyFileSync(file.path, filepath);

      logger.info('File uploaded successfully', {
        category,
        filename,
        size: file.size,
        originalName: file.originalname,
      });

      return {
        success: true,
        filename,
        filepath: `/uploads/${category}/${filename}`,
        originalName: file.originalname,
        size: file.size,
        mimetype: file.mimetype,
      };
    } catch (error) {
      logger.error('File upload failed', { error: error.message });
      return { success: false, error: error.message };
    }
  }

  /**
   * Delete file
   */
  deleteFile(filename, category = 'documents') {
    try {
      const filepath = path.join(this.uploadDir, category, filename);

      // Security check: ensure filepath is within uploadDir
      const realPath = path.resolve(filepath);
      const uploadDirReal = path.resolve(this.uploadDir);

      if (!realPath.startsWith(uploadDirReal)) {
        logger.warn('Attempted to delete file outside upload directory', { filepath });
        return { success: false, error: 'Invalid file path' };
      }

      if (fs.existsSync(realPath)) {
        fs.unlinkSync(realPath);
        logger.info('File deleted successfully', { filename, category });
        return { success: true };
      }

      return { success: false, error: 'File not found' };
    } catch (error) {
      logger.error('File deletion failed', { error: error.message });
      return { success: false, error: error.message };
    }
  }

  /**
   * Get file information
   */
  getFileInfo(filename, category = 'documents') {
    try {
      const filepath = path.join(this.uploadDir, category, filename);

      if (!fs.existsSync(filepath)) {
        return { success: false, error: 'File not found' };
      }

      const stats = fs.statSync(filepath);

      return {
        success: true,
        filename,
        category,
        size: stats.size,
        createdAt: stats.birthtime,
        modifiedAt: stats.mtime,
      };
    } catch (error) {
      logger.error('Failed to get file info', { error: error.message });
      return { success: false, error: error.message };
    }
  }

  /**
   * Get all files in a category
   */
  getFilesByCategory(category) {
    try {
      const categoryDir = path.join(this.uploadDir, category);

      if (!fs.existsSync(categoryDir)) {
        return { success: true, files: [] };
      }

      const files = fs.readdirSync(categoryDir).map(filename => {
        const filepath = path.join(categoryDir, filename);
        const stats = fs.statSync(filepath);

        return {
          filename,
          size: stats.size,
          createdAt: stats.birthtime,
          url: `/uploads/${category}/${filename}`,
        };
      });

      return { success: true, files };
    } catch (error) {
      logger.error('Failed to get files by category', { error: error.message });
      return { success: false, error: error.message };
    }
  }

  /**
   * Cleanup old files (older than specified days)
   */
  cleanupOldFiles(category, daysOld = 30) {
    try {
      const categoryDir = path.join(this.uploadDir, category);
      const cutoffTime = Date.now() - daysOld * 24 * 60 * 60 * 1000;
      let deletedCount = 0;

      if (!fs.existsSync(categoryDir)) {
        return { success: true, deletedCount: 0 };
      }

      const files = fs.readdirSync(categoryDir);

      files.forEach(filename => {
        const filepath = path.join(categoryDir, filename);
        const stats = fs.statSync(filepath);

        if (stats.mtime.getTime() < cutoffTime) {
          fs.unlinkSync(filepath);
          deletedCount++;
        }
      });

      logger.info('Old files cleaned up', { category, daysOld, deletedCount });
      return { success: true, deletedCount };
    } catch (error) {
      logger.error('File cleanup failed', { error: error.message });
      return { success: false, error: error.message };
    }
  }
}

module.exports = new FileStorageManager();
