-- Database Views for Common Reporting and Analytics
-- These views simplify queries and improve performance

-- Employee Dashboard View
CREATE OR REPLACE VIEW employee_dashboard_view AS
SELECT 
  e.id,
  e.first_name,
  e.last_name,
  e.email,
  e.phone,
  d.name AS department_name,
  d.id AS department_id,
  e.salary,
  e.join_date,
  COUNT(DISTINCT l.id) AS total_leaves_taken,
  SUM(CASE WHEN l.status = 'approved' THEN 1 ELSE 0 END) AS approved_leaves,
  COUNT(DISTINCT a.id) AS assigned_assets,
  e.status
FROM employees e
LEFT JOIN departments d ON e.department_id = d.id
LEFT JOIN leaves l ON e.id = l.employee_id
LEFT JOIN assets a ON e.id = a.assigned_to
GROUP BY e.id, d.id;

-- Leave Summary View
CREATE OR REPLACE VIEW leave_summary_view AS
SELECT 
  e.id AS employee_id,
  CONCAT(e.first_name, ' ', e.last_name) AS employee_name,
  d.name AS department_name,
  lt.name AS leave_type,
  COUNT(*) AS total_requests,
  SUM(CASE WHEN l.status = 'approved' THEN 1 ELSE 0 END) AS approved,
  SUM(CASE WHEN l.status = 'pending' THEN 1 ELSE 0 END) AS pending,
  SUM(CASE WHEN l.status = 'rejected' THEN 1 ELSE 0 END) AS rejected,
  SUM(CASE WHEN l.status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled,
  EXTRACT(YEAR FROM l.start_date) AS year
FROM leaves l
JOIN employees e ON l.employee_id = e.id
JOIN departments d ON e.department_id = d.id
JOIN leave_types lt ON l.leave_type_id = lt.id
GROUP BY e.id, d.id, lt.id;

-- Asset Summary View
CREATE OR REPLACE VIEW asset_summary_view AS
SELECT 
  a.id,
  a.asset_name,
  a.asset_code,
  a.category,
  a.status,
  CASE 
    WHEN a.assigned_to IS NOT NULL 
    THEN CONCAT(e.first_name, ' ', e.last_name)
    ELSE 'Unassigned'
  END AS assigned_to_name,
  a.purchase_price,
  a.purchase_date,
  CASE 
    WHEN a.status = 'assigned' THEN 'In Use'
    WHEN a.status = 'available' THEN 'Available'
    WHEN a.status = 'maintenance' THEN 'Under Maintenance'
    WHEN a.status = 'retired' THEN 'Retired'
    ELSE 'Unknown'
  END AS status_label,
  (CURRENT_DATE - a.purchase_date) / 365.25 AS age_in_years
FROM assets a
LEFT JOIN employees e ON a.assigned_to = e.id;

-- Department Payroll Summary View
CREATE OR REPLACE VIEW department_payroll_view AS
SELECT 
  d.id,
  d.name AS department_name,
  COUNT(DISTINCT e.id) AS total_employees,
  COUNT(DISTINCT CASE WHEN e.status = 'active' THEN e.id END) AS active_employees,
  SUM(e.salary) AS total_payroll,
  AVG(e.salary) AS average_salary,
  MIN(e.salary) AS min_salary,
  MAX(e.salary) AS max_salary,
  STDDEV(e.salary) AS salary_stddev
FROM departments d
LEFT JOIN employees e ON d.id = e.department_id
GROUP BY d.id;

-- Monthly Leave Statistics View
CREATE OR REPLACE VIEW monthly_leave_statistics AS
SELECT 
  DATE_TRUNC('month', l.start_date)::DATE AS month,
  COUNT(*) AS total_leaves,
  SUM(CASE WHEN l.status = 'approved' THEN 1 ELSE 0 END) AS approved_leaves,
  SUM(CASE WHEN l.status = 'pending' THEN 1 ELSE 0 END) AS pending_leaves,
  SUM(CASE WHEN l.status = 'rejected' THEN 1 ELSE 0 END) AS rejected_leaves,
  COUNT(DISTINCT l.employee_id) AS employees_on_leave
FROM leaves l
GROUP BY DATE_TRUNC('month', l.start_date);

-- User Activity View
CREATE OR REPLACE VIEW user_activity_view AS
SELECT 
  u.id,
  u.email,
  COUNT(DISTINCT CASE WHEN al.action = 'login' THEN al.id END) AS login_count,
  MAX(CASE WHEN al.action = 'login' THEN al.created_at END) AS last_login,
  COUNT(DISTINCT al.id) AS total_actions,
  u.created_at AS account_created_date
FROM users u
LEFT JOIN audit_logs al ON u.id = al.user_id
GROUP BY u.id;

-- Skills Distribution View
CREATE OR REPLACE VIEW skills_distribution_view AS
SELECT 
  s.id,
  s.name AS skill_name,
  COUNT(DISTINCT es.employee_id) AS employee_count,
  COUNT(DISTINCT e.department_id) AS departments_with_skill,
  STRING_AGG(DISTINCT d.name, ', ') AS departments
FROM skills s
LEFT JOIN employee_skills es ON s.id = es.skill_id
LEFT JOIN employees e ON es.employee_id = e.id
LEFT JOIN departments d ON e.department_id = d.id
GROUP BY s.id;
