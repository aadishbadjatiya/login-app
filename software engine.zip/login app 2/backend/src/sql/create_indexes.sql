-- Database Indexing for Performance Optimization
-- These indexes improve query performance for common operations

-- User and Authentication Indexes
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_status ON users(status);
CREATE INDEX IF NOT EXISTS idx_users_created_at ON users(created_at);

-- Employee Indexes
CREATE INDEX IF NOT EXISTS idx_employees_email ON employees(email);
CREATE INDEX IF NOT EXISTS idx_employees_department_id ON employees(department_id);
CREATE INDEX IF NOT EXISTS idx_employees_status ON employees(status);
CREATE INDEX IF NOT EXISTS idx_employees_join_date ON employees(join_date);
CREATE INDEX IF NOT EXISTS idx_employees_phone ON employees(phone);
CREATE INDEX IF NOT EXISTS idx_employees_first_name_last_name ON employees(first_name, last_name);

-- Department Indexes
CREATE INDEX IF NOT EXISTS idx_departments_name ON departments(name);
CREATE INDEX IF NOT EXISTS idx_departments_manager_id ON departments(manager_id);

-- Leave Indexes
CREATE INDEX IF NOT EXISTS idx_leaves_employee_id ON leaves(employee_id);
CREATE INDEX IF NOT EXISTS idx_leaves_status ON leaves(status);
CREATE INDEX IF NOT EXISTS idx_leaves_start_date ON leaves(start_date);
CREATE INDEX IF NOT EXISTS idx_leaves_end_date ON leaves(end_date);
CREATE INDEX IF NOT EXISTS idx_leaves_leave_type_id ON leaves(leave_type_id);
CREATE INDEX IF NOT EXISTS idx_leaves_created_at ON leaves(created_at);

-- Asset Indexes
CREATE INDEX IF NOT EXISTS idx_assets_asset_code ON assets(asset_code);
CREATE INDEX IF NOT EXISTS idx_assets_category ON assets(category);
CREATE INDEX IF NOT EXISTS idx_assets_status ON assets(status);
CREATE INDEX IF NOT EXISTS idx_assets_assigned_to ON assets(assigned_to);
CREATE INDEX IF NOT EXISTS idx_assets_purchase_date ON assets(purchase_date);

-- Skill Indexes
CREATE INDEX IF NOT EXISTS idx_skills_name ON skills(name);

-- Notification Indexes
CREATE INDEX IF NOT EXISTS idx_notifications_recipient_id ON notifications(recipient_id);
CREATE INDEX IF NOT EXISTS idx_notifications_is_read ON notifications(is_read);
CREATE INDEX IF NOT EXISTS idx_notifications_created_at ON notifications(created_at);

-- Audit Indexes
CREATE INDEX IF NOT EXISTS idx_audit_user_id ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_logs(action);
CREATE INDEX IF NOT EXISTS idx_audit_created_at ON audit_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_audit_table_name ON audit_logs(table_name);

-- Composite Indexes for common queries
CREATE INDEX IF NOT EXISTS idx_leaves_employee_status_date ON leaves(employee_id, status, start_date);
CREATE INDEX IF NOT EXISTS idx_assets_category_status ON assets(category, status);
CREATE INDEX IF NOT EXISTS idx_employees_department_status ON employees(department_id, status);

-- Performance tip: Analyze tables after creating indexes
ANALYZE users;
ANALYZE employees;
ANALYZE departments;
ANALYZE leaves;
ANALYZE assets;
ANALYZE skills;
ANALYZE notifications;
ANALYZE audit_logs;
